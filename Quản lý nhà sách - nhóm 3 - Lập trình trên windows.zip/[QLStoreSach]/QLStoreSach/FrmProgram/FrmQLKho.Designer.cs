﻿namespace QLStoreSach.FrmProgram
{
    partial class FrmQLKho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQLKho));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.label4 = new System.Windows.Forms.Label();
            this.grbDS = new System.Windows.Forms.GroupBox();
            this.bunifuCheckBox2 = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.bunifuCheckBox1 = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTimKiem = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.btnSua = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.lvDS = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnXuat = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnNhap = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grbDS.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Broadway", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.label4.Location = new System.Drawing.Point(10, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(281, 24);
            this.label4.TabIndex = 12;
            this.label4.Text = "Inventory Management";
            // 
            // grbDS
            // 
            this.grbDS.BackColor = System.Drawing.Color.White;
            this.grbDS.Controls.Add(this.bunifuCheckBox2);
            this.grbDS.Controls.Add(this.bunifuCheckBox1);
            this.grbDS.Controls.Add(this.label3);
            this.grbDS.Controls.Add(this.label2);
            this.grbDS.Controls.Add(this.label1);
            this.grbDS.Controls.Add(this.tbTimKiem);
            this.grbDS.Controls.Add(this.btnSua);
            this.grbDS.Controls.Add(this.lvDS);
            this.grbDS.Controls.Add(this.btnXuat);
            this.grbDS.Controls.Add(this.btnNhap);
            this.grbDS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDS.Location = new System.Drawing.Point(12, 30);
            this.grbDS.Name = "grbDS";
            this.grbDS.Size = new System.Drawing.Size(850, 526);
            this.grbDS.TabIndex = 17;
            this.grbDS.TabStop = false;
            // 
            // bunifuCheckBox2
            // 
            this.bunifuCheckBox2.AllowBindingControlAnimation = true;
            this.bunifuCheckBox2.AllowBindingControlColorChanges = false;
            this.bunifuCheckBox2.AllowBindingControlLocation = true;
            this.bunifuCheckBox2.AllowCheckBoxAnimation = false;
            this.bunifuCheckBox2.AllowCheckmarkAnimation = true;
            this.bunifuCheckBox2.AllowOnHoverStates = true;
            this.bunifuCheckBox2.AutoCheck = true;
            this.bunifuCheckBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCheckBox2.BackgroundImage")));
            this.bunifuCheckBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bunifuCheckBox2.BindingControl = null;
            this.bunifuCheckBox2.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.bunifuCheckBox2.Checked = false;
            this.bunifuCheckBox2.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.bunifuCheckBox2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuCheckBox2.CustomCheckmarkImage = null;
            this.bunifuCheckBox2.Location = new System.Drawing.Point(813, 48);
            this.bunifuCheckBox2.MinimumSize = new System.Drawing.Size(17, 17);
            this.bunifuCheckBox2.Name = "bunifuCheckBox2";
            this.bunifuCheckBox2.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnCheck.BorderRadius = 2;
            this.bunifuCheckBox2.OnCheck.BorderThickness = 2;
            this.bunifuCheckBox2.OnCheck.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnCheck.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnDisable.BorderColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnDisable.BorderRadius = 2;
            this.bunifuCheckBox2.OnDisable.BorderThickness = 2;
            this.bunifuCheckBox2.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnDisable.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnDisable.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnHoverChecked.BorderRadius = 2;
            this.bunifuCheckBox2.OnHoverChecked.BorderThickness = 2;
            this.bunifuCheckBox2.OnHoverChecked.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox2.OnHoverChecked.CheckmarkThickness = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnHoverUnchecked.BorderRadius = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.BorderThickness = 2;
            this.bunifuCheckBox2.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox2.OnUncheck.BorderRadius = 2;
            this.bunifuCheckBox2.OnUncheck.BorderThickness = 2;
            this.bunifuCheckBox2.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox2.Size = new System.Drawing.Size(21, 21);
            this.bunifuCheckBox2.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Round;
            this.bunifuCheckBox2.TabIndex = 43;
            this.bunifuCheckBox2.ThreeState = false;
            this.bunifuCheckBox2.ToolTipText = null;
            this.bunifuCheckBox2.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.bunifuCheckBox2_CheckedChanged);
            // 
            // bunifuCheckBox1
            // 
            this.bunifuCheckBox1.AllowBindingControlAnimation = true;
            this.bunifuCheckBox1.AllowBindingControlColorChanges = false;
            this.bunifuCheckBox1.AllowBindingControlLocation = true;
            this.bunifuCheckBox1.AllowCheckBoxAnimation = false;
            this.bunifuCheckBox1.AllowCheckmarkAnimation = true;
            this.bunifuCheckBox1.AllowOnHoverStates = true;
            this.bunifuCheckBox1.AutoCheck = true;
            this.bunifuCheckBox1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCheckBox1.BackgroundImage")));
            this.bunifuCheckBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bunifuCheckBox1.BindingControl = null;
            this.bunifuCheckBox1.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.bunifuCheckBox1.Checked = false;
            this.bunifuCheckBox1.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.bunifuCheckBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuCheckBox1.CustomCheckmarkImage = null;
            this.bunifuCheckBox1.Location = new System.Drawing.Point(813, 21);
            this.bunifuCheckBox1.MinimumSize = new System.Drawing.Size(17, 17);
            this.bunifuCheckBox1.Name = "bunifuCheckBox1";
            this.bunifuCheckBox1.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnCheck.BorderRadius = 1;
            this.bunifuCheckBox1.OnCheck.BorderThickness = 2;
            this.bunifuCheckBox1.OnCheck.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox1.OnCheck.CheckmarkThickness = 2;
            this.bunifuCheckBox1.OnDisable.BorderColor = System.Drawing.Color.White;
            this.bunifuCheckBox1.OnDisable.BorderRadius = 1;
            this.bunifuCheckBox1.OnDisable.BorderThickness = 2;
            this.bunifuCheckBox1.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox1.OnDisable.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox1.OnDisable.CheckmarkThickness = 2;
            this.bunifuCheckBox1.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnHoverChecked.BorderRadius = 1;
            this.bunifuCheckBox1.OnHoverChecked.BorderThickness = 2;
            this.bunifuCheckBox1.OnHoverChecked.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.bunifuCheckBox1.OnHoverChecked.CheckmarkThickness = 2;
            this.bunifuCheckBox1.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnHoverUnchecked.BorderRadius = 1;
            this.bunifuCheckBox1.OnHoverUnchecked.BorderThickness = 2;
            this.bunifuCheckBox1.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox1.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuCheckBox1.OnUncheck.BorderRadius = 1;
            this.bunifuCheckBox1.OnUncheck.BorderThickness = 2;
            this.bunifuCheckBox1.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.bunifuCheckBox1.Size = new System.Drawing.Size(21, 21);
            this.bunifuCheckBox1.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Round;
            this.bunifuCheckBox1.TabIndex = 43;
            this.bunifuCheckBox1.ThreeState = false;
            this.bunifuCheckBox1.ToolTipText = "";
            this.bunifuCheckBox1.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.bunifuCheckBox1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label3.Location = new System.Drawing.Point(735, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 42;
            this.label3.Text = "Giảm dần";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label2.Location = new System.Drawing.Point(735, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 42;
            this.label2.Text = "Tăng dần";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label1.Location = new System.Drawing.Point(609, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 17);
            this.label1.TabIndex = 42;
            this.label1.Text = "Sắp xếp số lượng :";
            // 
            // tbTimKiem
            // 
            this.tbTimKiem.AcceptsReturn = false;
            this.tbTimKiem.AcceptsTab = false;
            this.tbTimKiem.AnimationSpeed = 200;
            this.tbTimKiem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbTimKiem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbTimKiem.BackColor = System.Drawing.Color.Transparent;
            this.tbTimKiem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.BackgroundImage")));
            this.tbTimKiem.BorderColorActive = System.Drawing.Color.White;
            this.tbTimKiem.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tbTimKiem.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.tbTimKiem.BorderRadius = 35;
            this.tbTimKiem.BorderThickness = 1;
            this.tbTimKiem.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbTimKiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTimKiem.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F);
            this.tbTimKiem.DefaultText = "";
            this.tbTimKiem.FillColor = System.Drawing.Color.White;
            this.tbTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.HideSelection = true;
            this.tbTimKiem.IconLeft = null;
            this.tbTimKiem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.IconPadding = 10;
            this.tbTimKiem.IconRight = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.IconRight")));
            this.tbTimKiem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.Lines = new string[0];
            this.tbTimKiem.Location = new System.Drawing.Point(16, 19);
            this.tbTimKiem.MaxLength = 32767;
            this.tbTimKiem.MinimumSize = new System.Drawing.Size(100, 35);
            this.tbTimKiem.Modified = false;
            this.tbTimKiem.Multiline = false;
            this.tbTimKiem.Name = "tbTimKiem";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties1.FillColor = System.Drawing.Color.White;
            stateProperties1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbTimKiem.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties3.FillColor = System.Drawing.Color.White;
            stateProperties3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnIdleState = stateProperties4;
            this.tbTimKiem.PasswordChar = '\0';
            this.tbTimKiem.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.PlaceholderText = "Tìm kiếm sách";
            this.tbTimKiem.ReadOnly = false;
            this.tbTimKiem.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbTimKiem.SelectedText = "";
            this.tbTimKiem.SelectionLength = 0;
            this.tbTimKiem.SelectionStart = 0;
            this.tbTimKiem.ShortcutsEnabled = true;
            this.tbTimKiem.Size = new System.Drawing.Size(312, 35);
            this.tbTimKiem.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tbTimKiem.TabIndex = 8;
            this.tbTimKiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbTimKiem.TextMarginBottom = 0;
            this.tbTimKiem.TextMarginLeft = 5;
            this.tbTimKiem.TextMarginTop = 0;
            this.tbTimKiem.TextPlaceholder = "Tìm kiếm sách";
            this.tbTimKiem.UseSystemPasswordChar = false;
            this.tbTimKiem.WordWrap = true;
            // 
            // btnSua
            // 
            this.btnSua.AllowToggling = false;
            this.btnSua.AnimationSpeed = 200;
            this.btnSua.AutoGenerateColors = false;
            this.btnSua.BackColor = System.Drawing.Color.Transparent;
            this.btnSua.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnSua.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSua.BackgroundImage")));
            this.btnSua.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSua.ButtonText = "Xóa";
            this.btnSua.ButtonTextMarginLeft = 12;
            this.btnSua.ColorContrastOnClick = 45;
            this.btnSua.ColorContrastOnHover = 45;
            this.btnSua.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnSua.CustomizableEdges = borderEdges1;
            this.btnSua.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSua.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnSua.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSua.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnSua.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnSua.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnSua.ForeColor = System.Drawing.Color.White;
            this.btnSua.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnSua.IconMarginLeft = 11;
            this.btnSua.IconPadding = 6;
            this.btnSua.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnSua.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnSua.IdleBorderRadius = 3;
            this.btnSua.IdleBorderThickness = 1;
            this.btnSua.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnSua.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnSua.IdleIconLeftImage")));
            this.btnSua.IdleIconRightImage = null;
            this.btnSua.IndicateFocus = false;
            this.btnSua.Location = new System.Drawing.Point(730, 428);
            this.btnSua.Name = "btnSua";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties5.BorderRadius = 3;
            stateProperties5.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties5.BorderThickness = 1;
            stateProperties5.FillColor = System.Drawing.Color.White;
            stateProperties5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties5.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties5.IconLeftImage")));
            stateProperties5.IconRightImage = null;
            this.btnSua.onHoverState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Transparent;
            stateProperties6.BorderRadius = 3;
            stateProperties6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties6.BorderThickness = 1;
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties6.ForeColor = System.Drawing.Color.White;
            stateProperties6.IconLeftImage = null;
            stateProperties6.IconRightImage = null;
            this.btnSua.OnPressedState = stateProperties6;
            this.btnSua.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSua.Size = new System.Drawing.Size(110, 35);
            this.btnSua.TabIndex = 7;
            this.btnSua.TabStop = false;
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSua.TextMarginLeft = 12;
            this.btnSua.UseDefaultRadiusAndThickness = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // lvDS
            // 
            this.lvDS.BackColor = System.Drawing.Color.White;
            this.lvDS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvDS.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader4,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader5});
            this.lvDS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvDS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lvDS.FullRowSelect = true;
            this.lvDS.HideSelection = false;
            this.lvDS.Location = new System.Drawing.Point(16, 66);
            this.lvDS.Name = "lvDS";
            this.lvDS.Size = new System.Drawing.Size(700, 451);
            this.lvDS.TabIndex = 0;
            this.lvDS.UseCompatibleStateImageBehavior = false;
            this.lvDS.View = System.Windows.Forms.View.Details;
            this.lvDS.Click += new System.EventHandler(this.lvDS_Click);
            this.lvDS.DoubleClick += new System.EventHandler(this.lvDS_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã";
            this.columnHeader1.Width = 55;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Nhà cung cấp";
            this.columnHeader4.Width = 340;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Giá gốc";
            this.columnHeader7.Width = 85;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Số lượng";
            this.columnHeader8.Width = 70;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Ngày nhập kho";
            this.columnHeader5.Width = 120;
            // 
            // btnXuat
            // 
            this.btnXuat.AllowToggling = false;
            this.btnXuat.AnimationSpeed = 200;
            this.btnXuat.AutoGenerateColors = false;
            this.btnXuat.BackColor = System.Drawing.Color.Transparent;
            this.btnXuat.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnXuat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnXuat.BackgroundImage")));
            this.btnXuat.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnXuat.ButtonText = "Xuất file";
            this.btnXuat.ButtonTextMarginLeft = 15;
            this.btnXuat.ColorContrastOnClick = 45;
            this.btnXuat.ColorContrastOnHover = 45;
            this.btnXuat.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnXuat.CustomizableEdges = borderEdges2;
            this.btnXuat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnXuat.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnXuat.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnXuat.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnXuat.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnXuat.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnXuat.ForeColor = System.Drawing.Color.White;
            this.btnXuat.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnXuat.IconMarginLeft = 11;
            this.btnXuat.IconPadding = 6;
            this.btnXuat.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnXuat.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnXuat.IdleBorderRadius = 3;
            this.btnXuat.IdleBorderThickness = 1;
            this.btnXuat.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnXuat.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnXuat.IdleIconLeftImage")));
            this.btnXuat.IdleIconRightImage = null;
            this.btnXuat.IndicateFocus = false;
            this.btnXuat.Location = new System.Drawing.Point(730, 481);
            this.btnXuat.Name = "btnXuat";
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties7.BorderRadius = 3;
            stateProperties7.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties7.BorderThickness = 1;
            stateProperties7.FillColor = System.Drawing.Color.White;
            stateProperties7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties7.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties7.IconLeftImage")));
            stateProperties7.IconRightImage = null;
            this.btnXuat.onHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Transparent;
            stateProperties8.BorderRadius = 3;
            stateProperties8.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties8.BorderThickness = 1;
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties8.ForeColor = System.Drawing.Color.White;
            stateProperties8.IconLeftImage = null;
            stateProperties8.IconRightImage = null;
            this.btnXuat.OnPressedState = stateProperties8;
            this.btnXuat.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnXuat.Size = new System.Drawing.Size(110, 35);
            this.btnXuat.TabIndex = 5;
            this.btnXuat.TabStop = false;
            this.btnXuat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnXuat.TextMarginLeft = 15;
            this.btnXuat.UseDefaultRadiusAndThickness = true;
            this.btnXuat.Click += new System.EventHandler(this.btnXuat_Click_1);
            // 
            // btnNhap
            // 
            this.btnNhap.AllowToggling = false;
            this.btnNhap.AnimationSpeed = 200;
            this.btnNhap.AutoGenerateColors = false;
            this.btnNhap.BackColor = System.Drawing.Color.Transparent;
            this.btnNhap.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnNhap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNhap.BackgroundImage")));
            this.btnNhap.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnNhap.ButtonText = "Nhập";
            this.btnNhap.ButtonTextMarginLeft = 12;
            this.btnNhap.ColorContrastOnClick = 45;
            this.btnNhap.ColorContrastOnHover = 45;
            this.btnNhap.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnNhap.CustomizableEdges = borderEdges3;
            this.btnNhap.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnNhap.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnNhap.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnNhap.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnNhap.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnNhap.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnNhap.ForeColor = System.Drawing.Color.White;
            this.btnNhap.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnNhap.IconMarginLeft = 11;
            this.btnNhap.IconPadding = 6;
            this.btnNhap.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnNhap.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnNhap.IdleBorderRadius = 3;
            this.btnNhap.IdleBorderThickness = 1;
            this.btnNhap.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnNhap.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnNhap.IdleIconLeftImage")));
            this.btnNhap.IdleIconRightImage = null;
            this.btnNhap.IndicateFocus = false;
            this.btnNhap.Location = new System.Drawing.Point(730, 375);
            this.btnNhap.Name = "btnNhap";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties9.BorderRadius = 3;
            stateProperties9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.White;
            stateProperties9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties9.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties9.IconLeftImage")));
            stateProperties9.IconRightImage = null;
            this.btnNhap.onHoverState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Transparent;
            stateProperties10.BorderRadius = 3;
            stateProperties10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties10.ForeColor = System.Drawing.Color.White;
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.btnNhap.OnPressedState = stateProperties10;
            this.btnNhap.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnNhap.Size = new System.Drawing.Size(110, 35);
            this.btnNhap.TabIndex = 5;
            this.btnNhap.TabStop = false;
            this.btnNhap.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNhap.TextMarginLeft = 12;
            this.btnNhap.UseDefaultRadiusAndThickness = true;
            this.btnNhap.Click += new System.EventHandler(this.btnNhap_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grbDS);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(872, 568);
            this.panel2.TabIndex = 0;
            // 
            // FrmQLKho
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(872, 568);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmQLKho";
            this.Load += new System.EventHandler(this.FrmQLKho_Load_1);
            this.grbDS.ResumeLayout(false);
            this.grbDS.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grbDS;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSua;
        private System.Windows.Forms.ListView lvDS;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnXuat;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnNhap;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tbTimKiem;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuCheckBox bunifuCheckBox1;
        private Bunifu.UI.WinForms.BunifuCheckBox bunifuCheckBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}