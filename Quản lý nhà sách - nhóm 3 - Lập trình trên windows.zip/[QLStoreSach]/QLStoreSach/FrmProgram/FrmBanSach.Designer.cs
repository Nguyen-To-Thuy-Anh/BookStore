﻿namespace QLStoreSach.FrmProgram
{
    partial class FrmBanSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBanSach));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.label4 = new System.Windows.Forms.Label();
            this.panelMain = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbTimKiem = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lvSach = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSoLuong = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lbTongTien = new System.Windows.Forms.Label();
            this.bunifuButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lvXemTruoc = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bunifuButton4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnThemDuLieu = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbMaHoaDon = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtGiaBan = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTongTien = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTenSach = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtTenKH = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.panelMain.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.label4.Location = new System.Drawing.Point(9, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Selling books";
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.White;
            this.panelMain.Controls.Add(this.groupBox2);
            this.panelMain.Controls.Add(this.label4);
            this.panelMain.Controls.Add(this.groupBox1);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(872, 568);
            this.panelMain.TabIndex = 19;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.tbTimKiem);
            this.groupBox2.Controls.Add(this.lvSach);
            this.groupBox2.Location = new System.Drawing.Point(558, 36);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(302, 515);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            // 
            // tbTimKiem
            // 
            this.tbTimKiem.AcceptsReturn = false;
            this.tbTimKiem.AcceptsTab = false;
            this.tbTimKiem.AnimationSpeed = 200;
            this.tbTimKiem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbTimKiem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbTimKiem.BackColor = System.Drawing.Color.Transparent;
            this.tbTimKiem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.BackgroundImage")));
            this.tbTimKiem.BorderColorActive = System.Drawing.Color.White;
            this.tbTimKiem.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tbTimKiem.BorderColorHover = System.Drawing.Color.Black;
            this.tbTimKiem.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.tbTimKiem.BorderRadius = 35;
            this.tbTimKiem.BorderThickness = 1;
            this.tbTimKiem.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbTimKiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTimKiem.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTimKiem.DefaultText = "";
            this.tbTimKiem.FillColor = System.Drawing.Color.White;
            this.tbTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.HideSelection = true;
            this.tbTimKiem.IconLeft = null;
            this.tbTimKiem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.IconPadding = 10;
            this.tbTimKiem.IconRight = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.IconRight")));
            this.tbTimKiem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.Lines = new string[0];
            this.tbTimKiem.Location = new System.Drawing.Point(6, 17);
            this.tbTimKiem.MaxLength = 32767;
            this.tbTimKiem.MinimumSize = new System.Drawing.Size(100, 35);
            this.tbTimKiem.Modified = false;
            this.tbTimKiem.Multiline = false;
            this.tbTimKiem.Name = "tbTimKiem";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties1.FillColor = System.Drawing.Color.White;
            stateProperties1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbTimKiem.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties3.FillColor = System.Drawing.Color.White;
            stateProperties3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnIdleState = stateProperties4;
            this.tbTimKiem.PasswordChar = '\0';
            this.tbTimKiem.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.PlaceholderText = "Tìm kiếm Sách";
            this.tbTimKiem.ReadOnly = false;
            this.tbTimKiem.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbTimKiem.SelectedText = "";
            this.tbTimKiem.SelectionLength = 0;
            this.tbTimKiem.SelectionStart = 0;
            this.tbTimKiem.ShortcutsEnabled = true;
            this.tbTimKiem.Size = new System.Drawing.Size(287, 35);
            this.tbTimKiem.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tbTimKiem.TabIndex = 38;
            this.tbTimKiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbTimKiem.TextMarginBottom = 0;
            this.tbTimKiem.TextMarginLeft = 5;
            this.tbTimKiem.TextMarginTop = 0;
            this.tbTimKiem.TextPlaceholder = "Tìm kiếm Sách";
            this.tbTimKiem.UseSystemPasswordChar = false;
            this.tbTimKiem.WordWrap = true;
            this.tbTimKiem.TextChanged += new System.EventHandler(this.tbTimKiem_TextChanged);
            // 
            // lvSach
            // 
            this.lvSach.BackColor = System.Drawing.Color.White;
            this.lvSach.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvSach.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader7});
            this.lvSach.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lvSach.FullRowSelect = true;
            this.lvSach.HideSelection = false;
            this.lvSach.Location = new System.Drawing.Point(6, 63);
            this.lvSach.Name = "lvSach";
            this.lvSach.Size = new System.Drawing.Size(287, 446);
            this.lvSach.TabIndex = 37;
            this.lvSach.UseCompatibleStateImageBehavior = false;
            this.lvSach.View = System.Windows.Forms.View.Details;
            this.lvSach.Click += new System.EventHandler(this.lvSach_Click);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tên Sách";
            this.columnHeader4.Width = 185;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Giá";
            this.columnHeader7.Width = 70;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.txtSoLuong);
            this.groupBox1.Controls.Add(this.lbTongTien);
            this.groupBox1.Controls.Add(this.bunifuButton3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lvXemTruoc);
            this.groupBox1.Controls.Add(this.bunifuButton4);
            this.groupBox1.Controls.Add(this.btnThemDuLieu);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.lbMaHoaDon);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtGiaBan);
            this.groupBox1.Controls.Add(this.panel6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtTongTien);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.panel5);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtTenSach);
            this.groupBox1.Controls.Add(this.txtTenKH);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.groupBox1.Location = new System.Drawing.Point(10, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 515);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bán sách";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel1.Location = new System.Drawing.Point(14, 193);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 1);
            this.panel1.TabIndex = 32;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.AcceptsReturn = false;
            this.txtSoLuong.AcceptsTab = false;
            this.txtSoLuong.AnimationSpeed = 200;
            this.txtSoLuong.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSoLuong.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSoLuong.BackColor = System.Drawing.Color.Transparent;
            this.txtSoLuong.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSoLuong.BackgroundImage")));
            this.txtSoLuong.BorderColorActive = System.Drawing.Color.Empty;
            this.txtSoLuong.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtSoLuong.BorderColorHover = System.Drawing.Color.Empty;
            this.txtSoLuong.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtSoLuong.BorderRadius = 1;
            this.txtSoLuong.BorderThickness = 1;
            this.txtSoLuong.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSoLuong.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoLuong.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong.DefaultText = "";
            this.txtSoLuong.FillColor = System.Drawing.Color.White;
            this.txtSoLuong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtSoLuong.HideSelection = true;
            this.txtSoLuong.IconLeft = null;
            this.txtSoLuong.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoLuong.IconPadding = 10;
            this.txtSoLuong.IconRight = null;
            this.txtSoLuong.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSoLuong.Lines = new string[0];
            this.txtSoLuong.Location = new System.Drawing.Point(14, 161);
            this.txtSoLuong.MaxLength = 32767;
            this.txtSoLuong.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtSoLuong.Modified = false;
            this.txtSoLuong.Multiline = false;
            this.txtSoLuong.Name = "txtSoLuong";
            stateProperties5.BorderColor = System.Drawing.Color.Empty;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSoLuong.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Transparent;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSoLuong.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.Empty;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSoLuong.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Transparent;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSoLuong.OnIdleState = stateProperties8;
            this.txtSoLuong.PasswordChar = '\0';
            this.txtSoLuong.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtSoLuong.PlaceholderText = "Số lượng";
            this.txtSoLuong.ReadOnly = false;
            this.txtSoLuong.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSoLuong.SelectedText = "";
            this.txtSoLuong.SelectionLength = 0;
            this.txtSoLuong.SelectionStart = 0;
            this.txtSoLuong.ShortcutsEnabled = true;
            this.txtSoLuong.Size = new System.Drawing.Size(234, 33);
            this.txtSoLuong.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtSoLuong.TabIndex = 31;
            this.txtSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSoLuong.TextMarginBottom = 0;
            this.txtSoLuong.TextMarginLeft = 0;
            this.txtSoLuong.TextMarginTop = 0;
            this.txtSoLuong.TextPlaceholder = "Số lượng";
            this.txtSoLuong.UseSystemPasswordChar = false;
            this.txtSoLuong.WordWrap = true;
            this.txtSoLuong.TextChanged += new System.EventHandler(this.txtSoLuong_TextChanged);
            this.txtSoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoLuong_KeyPress);
            // 
            // lbTongTien
            // 
            this.lbTongTien.AutoSize = true;
            this.lbTongTien.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTongTien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbTongTien.Location = new System.Drawing.Point(350, 228);
            this.lbTongTien.Name = "lbTongTien";
            this.lbTongTien.Size = new System.Drawing.Size(0, 17);
            this.lbTongTien.TabIndex = 17;
            // 
            // bunifuButton3
            // 
            this.bunifuButton3.AllowToggling = false;
            this.bunifuButton3.AnimationSpeed = 200;
            this.bunifuButton3.AutoGenerateColors = false;
            this.bunifuButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.BackgroundImage")));
            this.bunifuButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.ButtonText = "Xóa";
            this.bunifuButton3.ButtonTextMarginLeft = 10;
            this.bunifuButton3.ColorContrastOnClick = 45;
            this.bunifuButton3.ColorContrastOnHover = 45;
            this.bunifuButton3.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton3.CustomizableEdges = borderEdges1;
            this.bunifuButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton3.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton3.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton3.DisabledForecolor = System.Drawing.Color.Gray;
            this.bunifuButton3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.bunifuButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton3.IconMarginLeft = 11;
            this.bunifuButton3.IconPadding = 6;
            this.bunifuButton3.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton3.IdleBorderColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.IdleBorderRadius = 3;
            this.bunifuButton3.IdleBorderThickness = 1;
            this.bunifuButton3.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton3.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.IdleIconLeftImage")));
            this.bunifuButton3.IdleIconRightImage = null;
            this.bunifuButton3.IndicateFocus = false;
            this.bunifuButton3.Location = new System.Drawing.Point(348, 267);
            this.bunifuButton3.Name = "bunifuButton3";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties9.BorderRadius = 3;
            stateProperties9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.White;
            stateProperties9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties9.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties9.IconLeftImage")));
            stateProperties9.IconRightImage = null;
            this.bunifuButton3.onHoverState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Transparent;
            stateProperties10.BorderRadius = 3;
            stateProperties10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties10.ForeColor = System.Drawing.Color.White;
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.bunifuButton3.OnPressedState = stateProperties10;
            this.bunifuButton3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuButton3.Size = new System.Drawing.Size(87, 33);
            this.bunifuButton3.TabIndex = 34;
            this.bunifuButton3.TabStop = false;
            this.bunifuButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton3.TextMarginLeft = 10;
            this.bunifuButton3.UseDefaultRadiusAndThickness = true;
            this.bunifuButton3.Click += new System.EventHandler(this.bunifuButton3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label1.Location = new System.Drawing.Point(276, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "Tổng tiền :";
            // 
            // lvXemTruoc
            // 
            this.lvXemTruoc.BackColor = System.Drawing.Color.White;
            this.lvXemTruoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvXemTruoc.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader5,
            this.columnHeader6});
            this.lvXemTruoc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lvXemTruoc.FullRowSelect = true;
            this.lvXemTruoc.HideSelection = false;
            this.lvXemTruoc.Location = new System.Drawing.Point(6, 306);
            this.lvXemTruoc.Name = "lvXemTruoc";
            this.lvXemTruoc.Size = new System.Drawing.Size(528, 203);
            this.lvXemTruoc.TabIndex = 36;
            this.lvXemTruoc.UseCompatibleStateImageBehavior = false;
            this.lvXemTruoc.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "STT";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên sách";
            this.columnHeader2.Width = 245;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "SL";
            this.columnHeader3.Width = 40;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Giá bán";
            this.columnHeader5.Width = 90;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Thành tiền";
            this.columnHeader6.Width = 90;
            // 
            // bunifuButton4
            // 
            this.bunifuButton4.AllowToggling = false;
            this.bunifuButton4.AnimationSpeed = 200;
            this.bunifuButton4.AutoGenerateColors = false;
            this.bunifuButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton4.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.BackgroundImage")));
            this.bunifuButton4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton4.ButtonText = "Lưu";
            this.bunifuButton4.ButtonTextMarginLeft = 10;
            this.bunifuButton4.ColorContrastOnClick = 45;
            this.bunifuButton4.ColorContrastOnHover = 45;
            this.bunifuButton4.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.bunifuButton4.CustomizableEdges = borderEdges2;
            this.bunifuButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton4.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton4.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton4.DisabledForecolor = System.Drawing.Color.Gray;
            this.bunifuButton4.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton4.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.bunifuButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuButton4.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton4.IconMarginLeft = 11;
            this.bunifuButton4.IconPadding = 6;
            this.bunifuButton4.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton4.IdleBorderColor = System.Drawing.Color.Transparent;
            this.bunifuButton4.IdleBorderRadius = 3;
            this.bunifuButton4.IdleBorderThickness = 1;
            this.bunifuButton4.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton4.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton4.IdleIconLeftImage")));
            this.bunifuButton4.IdleIconRightImage = null;
            this.bunifuButton4.IndicateFocus = false;
            this.bunifuButton4.Location = new System.Drawing.Point(445, 267);
            this.bunifuButton4.Name = "bunifuButton4";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties11.BorderRadius = 3;
            stateProperties11.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.White;
            stateProperties11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties11.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties11.IconLeftImage")));
            stateProperties11.IconRightImage = null;
            this.bunifuButton4.onHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Transparent;
            stateProperties12.BorderRadius = 3;
            stateProperties12.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties12.ForeColor = System.Drawing.Color.White;
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.bunifuButton4.OnPressedState = stateProperties12;
            this.bunifuButton4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuButton4.Size = new System.Drawing.Size(87, 33);
            this.bunifuButton4.TabIndex = 34;
            this.bunifuButton4.TabStop = false;
            this.bunifuButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton4.TextMarginLeft = 10;
            this.bunifuButton4.UseDefaultRadiusAndThickness = true;
            this.bunifuButton4.Click += new System.EventHandler(this.bunifuButton4_Click);
            // 
            // btnThemDuLieu
            // 
            this.btnThemDuLieu.AllowToggling = false;
            this.btnThemDuLieu.AnimationSpeed = 200;
            this.btnThemDuLieu.AutoGenerateColors = false;
            this.btnThemDuLieu.BackColor = System.Drawing.Color.Transparent;
            this.btnThemDuLieu.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnThemDuLieu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThemDuLieu.BackgroundImage")));
            this.btnThemDuLieu.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnThemDuLieu.ButtonText = "Thêm";
            this.btnThemDuLieu.ButtonTextMarginLeft = 10;
            this.btnThemDuLieu.ColorContrastOnClick = 45;
            this.btnThemDuLieu.ColorContrastOnHover = 45;
            this.btnThemDuLieu.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnThemDuLieu.CustomizableEdges = borderEdges3;
            this.btnThemDuLieu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnThemDuLieu.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnThemDuLieu.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnThemDuLieu.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnThemDuLieu.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnThemDuLieu.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemDuLieu.ForeColor = System.Drawing.Color.White;
            this.btnThemDuLieu.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnThemDuLieu.IconMarginLeft = 11;
            this.btnThemDuLieu.IconPadding = 6;
            this.btnThemDuLieu.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnThemDuLieu.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnThemDuLieu.IdleBorderRadius = 3;
            this.btnThemDuLieu.IdleBorderThickness = 1;
            this.btnThemDuLieu.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnThemDuLieu.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnThemDuLieu.IdleIconLeftImage")));
            this.btnThemDuLieu.IdleIconRightImage = null;
            this.btnThemDuLieu.IndicateFocus = false;
            this.btnThemDuLieu.Location = new System.Drawing.Point(251, 267);
            this.btnThemDuLieu.Name = "btnThemDuLieu";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties13.BorderRadius = 3;
            stateProperties13.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.White;
            stateProperties13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties13.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties13.IconLeftImage")));
            stateProperties13.IconRightImage = null;
            this.btnThemDuLieu.onHoverState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Transparent;
            stateProperties14.BorderRadius = 3;
            stateProperties14.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties14.ForeColor = System.Drawing.Color.White;
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.btnThemDuLieu.OnPressedState = stateProperties14;
            this.btnThemDuLieu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnThemDuLieu.Size = new System.Drawing.Size(87, 33);
            this.btnThemDuLieu.TabIndex = 34;
            this.btnThemDuLieu.TabStop = false;
            this.btnThemDuLieu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnThemDuLieu.TextMarginLeft = 10;
            this.btnThemDuLieu.UseDefaultRadiusAndThickness = true;
            this.btnThemDuLieu.Click += new System.EventHandler(this.btnThemDuLieu_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel4.Location = new System.Drawing.Point(270, 193);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(262, 1);
            this.panel4.TabIndex = 30;
            // 
            // lbMaHoaDon
            // 
            this.lbMaHoaDon.AutoSize = true;
            this.lbMaHoaDon.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaHoaDon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbMaHoaDon.Location = new System.Drawing.Point(95, 276);
            this.lbMaHoaDon.Name = "lbMaHoaDon";
            this.lbMaHoaDon.Size = new System.Drawing.Size(25, 17);
            this.lbMaHoaDon.TabIndex = 28;
            this.lbMaHoaDon.Text = ". . .";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label2.Location = new System.Drawing.Point(7, 275);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 28;
            this.label2.Text = "Mã hóa đơn :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label3.Location = new System.Drawing.Point(276, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 28;
            this.label3.Text = "Giá bán";
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.AcceptsReturn = false;
            this.txtGiaBan.AcceptsTab = false;
            this.txtGiaBan.AnimationSpeed = 200;
            this.txtGiaBan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtGiaBan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtGiaBan.BackColor = System.Drawing.Color.Transparent;
            this.txtGiaBan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtGiaBan.BackgroundImage")));
            this.txtGiaBan.BorderColorActive = System.Drawing.Color.Empty;
            this.txtGiaBan.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtGiaBan.BorderColorHover = System.Drawing.Color.Empty;
            this.txtGiaBan.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtGiaBan.BorderRadius = 1;
            this.txtGiaBan.BorderThickness = 1;
            this.txtGiaBan.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtGiaBan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaBan.DefaultText = "";
            this.txtGiaBan.FillColor = System.Drawing.Color.White;
            this.txtGiaBan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaBan.HideSelection = true;
            this.txtGiaBan.IconLeft = null;
            this.txtGiaBan.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.IconPadding = 10;
            this.txtGiaBan.IconRight = null;
            this.txtGiaBan.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.Lines = new string[0];
            this.txtGiaBan.Location = new System.Drawing.Point(270, 162);
            this.txtGiaBan.MaxLength = 32767;
            this.txtGiaBan.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtGiaBan.Modified = false;
            this.txtGiaBan.Multiline = false;
            this.txtGiaBan.Name = "txtGiaBan";
            stateProperties15.BorderColor = System.Drawing.Color.Empty;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnActiveState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Transparent;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtGiaBan.OnDisabledState = stateProperties16;
            stateProperties17.BorderColor = System.Drawing.Color.Empty;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnHoverState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Transparent;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnIdleState = stateProperties18;
            this.txtGiaBan.PasswordChar = '\0';
            this.txtGiaBan.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaBan.PlaceholderText = "Giá bán";
            this.txtGiaBan.ReadOnly = true;
            this.txtGiaBan.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGiaBan.SelectedText = "";
            this.txtGiaBan.SelectionLength = 0;
            this.txtGiaBan.SelectionStart = 0;
            this.txtGiaBan.ShortcutsEnabled = true;
            this.txtGiaBan.Size = new System.Drawing.Size(262, 33);
            this.txtGiaBan.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtGiaBan.TabIndex = 29;
            this.txtGiaBan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGiaBan.TextMarginBottom = 0;
            this.txtGiaBan.TextMarginLeft = 0;
            this.txtGiaBan.TextMarginTop = 0;
            this.txtGiaBan.TextPlaceholder = "Giá bán";
            this.txtGiaBan.UseSystemPasswordChar = false;
            this.txtGiaBan.WordWrap = true;
            this.txtGiaBan.TextChange += new System.EventHandler(this.txtGiaBan_TextChange);
            this.txtGiaBan.TextChanged += new System.EventHandler(this.txtGiaBan_TextChanged);
            this.txtGiaBan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGiaBan_KeyPress);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel6.Location = new System.Drawing.Point(14, 248);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(234, 1);
            this.panel6.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label8.Location = new System.Drawing.Point(20, 204);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "Thành tiền";
            // 
            // txtTongTien
            // 
            this.txtTongTien.AcceptsReturn = false;
            this.txtTongTien.AcceptsTab = false;
            this.txtTongTien.AnimationSpeed = 200;
            this.txtTongTien.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTongTien.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTongTien.BackColor = System.Drawing.Color.Transparent;
            this.txtTongTien.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTongTien.BackgroundImage")));
            this.txtTongTien.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTongTien.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTongTien.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTongTien.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTongTien.BorderRadius = 1;
            this.txtTongTien.BorderThickness = 1;
            this.txtTongTien.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTongTien.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTongTien.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien.DefaultText = "";
            this.txtTongTien.FillColor = System.Drawing.Color.White;
            this.txtTongTien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTongTien.HideSelection = true;
            this.txtTongTien.IconLeft = null;
            this.txtTongTien.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTongTien.IconPadding = 10;
            this.txtTongTien.IconRight = null;
            this.txtTongTien.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTongTien.Lines = new string[0];
            this.txtTongTien.Location = new System.Drawing.Point(14, 218);
            this.txtTongTien.MaxLength = 32767;
            this.txtTongTien.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTongTien.Modified = false;
            this.txtTongTien.Multiline = false;
            this.txtTongTien.Name = "txtTongTien";
            stateProperties19.BorderColor = System.Drawing.Color.Empty;
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTongTien.OnActiveState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Transparent;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTongTien.OnDisabledState = stateProperties20;
            stateProperties21.BorderColor = System.Drawing.Color.Empty;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTongTien.OnHoverState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Transparent;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTongTien.OnIdleState = stateProperties22;
            this.txtTongTien.PasswordChar = '\0';
            this.txtTongTien.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTongTien.PlaceholderText = "Thành tiền";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTongTien.SelectedText = "";
            this.txtTongTien.SelectionLength = 0;
            this.txtTongTien.SelectionStart = 0;
            this.txtTongTien.ShortcutsEnabled = true;
            this.txtTongTien.Size = new System.Drawing.Size(234, 33);
            this.txtTongTien.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTongTien.TabIndex = 32;
            this.txtTongTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTongTien.TextMarginBottom = 0;
            this.txtTongTien.TextMarginLeft = 0;
            this.txtTongTien.TextMarginTop = 0;
            this.txtTongTien.TextPlaceholder = "Thành tiền";
            this.txtTongTien.UseSystemPasswordChar = false;
            this.txtTongTien.WordWrap = true;
            this.txtTongTien.TextChanged += new System.EventHandler(this.txtTongTien_TextChanged);
            this.txtTongTien.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTongTien_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label5.Location = new System.Drawing.Point(20, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "Số lượng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label7.Location = new System.Drawing.Point(20, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 17);
            this.label7.TabIndex = 25;
            this.label7.Text = "Tên sách";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel5.Location = new System.Drawing.Point(14, 135);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(518, 1);
            this.panel5.TabIndex = 27;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel2.Location = new System.Drawing.Point(14, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(518, 1);
            this.panel2.TabIndex = 27;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label6.Location = new System.Drawing.Point(20, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Mã khách hàng";
            // 
            // txtTenSach
            // 
            this.txtTenSach.AcceptsReturn = false;
            this.txtTenSach.AcceptsTab = false;
            this.txtTenSach.AnimationSpeed = 200;
            this.txtTenSach.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTenSach.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTenSach.BackColor = System.Drawing.Color.Transparent;
            this.txtTenSach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTenSach.BackgroundImage")));
            this.txtTenSach.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTenSach.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTenSach.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTenSach.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTenSach.BorderRadius = 1;
            this.txtTenSach.BorderThickness = 1;
            this.txtTenSach.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTenSach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSach.DefaultText = "";
            this.txtTenSach.FillColor = System.Drawing.Color.White;
            this.txtTenSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenSach.HideSelection = true;
            this.txtTenSach.IconLeft = null;
            this.txtTenSach.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.IconPadding = 10;
            this.txtTenSach.IconRight = null;
            this.txtTenSach.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.Lines = new string[0];
            this.txtTenSach.Location = new System.Drawing.Point(14, 104);
            this.txtTenSach.MaxLength = 32767;
            this.txtTenSach.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTenSach.Modified = false;
            this.txtTenSach.Multiline = false;
            this.txtTenSach.Name = "txtTenSach";
            stateProperties23.BorderColor = System.Drawing.Color.Empty;
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnActiveState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Transparent;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTenSach.OnDisabledState = stateProperties24;
            stateProperties25.BorderColor = System.Drawing.Color.Empty;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnHoverState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Transparent;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnIdleState = stateProperties26;
            this.txtTenSach.PasswordChar = '\0';
            this.txtTenSach.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenSach.PlaceholderText = "Tên sách";
            this.txtTenSach.ReadOnly = true;
            this.txtTenSach.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTenSach.SelectedText = "";
            this.txtTenSach.SelectionLength = 0;
            this.txtTenSach.SelectionStart = 0;
            this.txtTenSach.ShortcutsEnabled = true;
            this.txtTenSach.Size = new System.Drawing.Size(518, 33);
            this.txtTenSach.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTenSach.TabIndex = 20;
            this.txtTenSach.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTenSach.TextMarginBottom = 0;
            this.txtTenSach.TextMarginLeft = 0;
            this.txtTenSach.TextMarginTop = 0;
            this.txtTenSach.TextPlaceholder = "Tên sách";
            this.txtTenSach.UseSystemPasswordChar = false;
            this.txtTenSach.WordWrap = true;
            this.txtTenSach.TextChange += new System.EventHandler(this.txtTenSach_TextChange);
            this.txtTenSach.TextChanged += new System.EventHandler(this.txtTenKH_TextChanged);
            // 
            // txtTenKH
            // 
            this.txtTenKH.AcceptsReturn = false;
            this.txtTenKH.AcceptsTab = false;
            this.txtTenKH.AnimationSpeed = 200;
            this.txtTenKH.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTenKH.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTenKH.BackColor = System.Drawing.Color.Transparent;
            this.txtTenKH.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTenKH.BackgroundImage")));
            this.txtTenKH.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTenKH.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTenKH.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTenKH.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTenKH.BorderRadius = 1;
            this.txtTenKH.BorderThickness = 1;
            this.txtTenKH.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTenKH.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenKH.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenKH.DefaultText = "";
            this.txtTenKH.FillColor = System.Drawing.Color.White;
            this.txtTenKH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenKH.HideSelection = true;
            this.txtTenKH.IconLeft = null;
            this.txtTenKH.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenKH.IconPadding = 10;
            this.txtTenKH.IconRight = null;
            this.txtTenKH.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenKH.Lines = new string[0];
            this.txtTenKH.Location = new System.Drawing.Point(14, 47);
            this.txtTenKH.MaxLength = 32767;
            this.txtTenKH.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTenKH.Modified = false;
            this.txtTenKH.Multiline = false;
            this.txtTenKH.Name = "txtTenKH";
            stateProperties27.BorderColor = System.Drawing.Color.Empty;
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenKH.OnActiveState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Transparent;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTenKH.OnDisabledState = stateProperties28;
            stateProperties29.BorderColor = System.Drawing.Color.Empty;
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenKH.OnHoverState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Transparent;
            stateProperties30.FillColor = System.Drawing.Color.White;
            stateProperties30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenKH.OnIdleState = stateProperties30;
            this.txtTenKH.PasswordChar = '\0';
            this.txtTenKH.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenKH.PlaceholderText = "Mã khách hàng";
            this.txtTenKH.ReadOnly = false;
            this.txtTenKH.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTenKH.SelectedText = "";
            this.txtTenKH.SelectionLength = 0;
            this.txtTenKH.SelectionStart = 0;
            this.txtTenKH.ShortcutsEnabled = true;
            this.txtTenKH.Size = new System.Drawing.Size(518, 33);
            this.txtTenKH.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTenKH.TabIndex = 20;
            this.txtTenKH.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTenKH.TextMarginBottom = 0;
            this.txtTenKH.TextMarginLeft = 0;
            this.txtTenKH.TextMarginTop = 0;
            this.txtTenKH.TextPlaceholder = "Mã khách hàng";
            this.txtTenKH.UseSystemPasswordChar = false;
            this.txtTenKH.WordWrap = true;
            this.txtTenKH.TextChanged += new System.EventHandler(this.txtTenKH_TextChanged);
            // 
            // FrmBanSach
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(872, 568);
            this.Controls.Add(this.panelMain);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmBanSach";
            this.Text = "FrmDanhThu";
            this.Load += new System.EventHandler(this.FrmDoanhThu_Load);
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView lvSach;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSoLuong;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton3;
        private System.Windows.Forms.ListView lvXemTruoc;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnThemDuLieu;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtGiaBan;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTongTien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTenSach;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTenKH;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tbTimKiem;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Label lbTongTien;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbMaHoaDon;
        private System.Windows.Forms.Label label2;
    }
}