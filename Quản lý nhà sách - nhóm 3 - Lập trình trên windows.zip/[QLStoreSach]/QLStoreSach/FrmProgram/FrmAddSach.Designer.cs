﻿namespace QLStoreSach.FrmProgram
{
    partial class FrmAddSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAddSach));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties41 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties42 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties43 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties44 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties45 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties46 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties47 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties48 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties49 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties50 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties51 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties52 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties53 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties54 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbSoL = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.lbNgayN = new System.Windows.Forms.Label();
            this.lbGiaG = new System.Windows.Forms.Label();
            this.lbNhaCC = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lbTacG = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbMoT = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.grbThongTin = new System.Windows.Forms.GroupBox();
            this.txtSL = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtGiaGoc = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtNgayNhap = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtNCC = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtTacGia = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtMoTa = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lbNhaXB = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtNXB = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSua = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnThem = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnLuuSach = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbGiaB = new System.Windows.Forms.Label();
            this.lbNamSB = new System.Windows.Forms.Label();
            this.lbTheL = new System.Windows.Forms.Label();
            this.lbTenS = new System.Windows.Forms.Label();
            this.txtNamXB = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lbMaS = new System.Windows.Forms.Label();
            this.txtTenSach = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtGiaBan = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtTheLoai = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtMaSach = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.grbThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel9.Location = new System.Drawing.Point(434, 152);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(387, 1);
            this.panel9.TabIndex = 78;
            // 
            // lbSoL
            // 
            this.lbSoL.AutoSize = true;
            this.lbSoL.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbSoL.Location = new System.Drawing.Point(446, 104);
            this.lbSoL.Name = "lbSoL";
            this.lbSoL.Size = new System.Drawing.Size(56, 17);
            this.lbSoL.TabIndex = 76;
            this.lbSoL.Text = "Số lượng";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel15.Location = new System.Drawing.Point(22, 404);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(383, 1);
            this.panel15.TabIndex = 66;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel16.Location = new System.Drawing.Point(434, 278);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(387, 1);
            this.panel16.TabIndex = 69;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel17.Location = new System.Drawing.Point(434, 89);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(387, 1);
            this.panel17.TabIndex = 65;
            // 
            // lbNgayN
            // 
            this.lbNgayN.AutoSize = true;
            this.lbNgayN.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayN.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbNgayN.Location = new System.Drawing.Point(29, 356);
            this.lbNgayN.Name = "lbNgayN";
            this.lbNgayN.Size = new System.Drawing.Size(67, 17);
            this.lbNgayN.TabIndex = 59;
            this.lbNgayN.Text = "Ngày nhập";
            // 
            // lbGiaG
            // 
            this.lbGiaG.AutoSize = true;
            this.lbGiaG.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGiaG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbGiaG.Location = new System.Drawing.Point(446, 230);
            this.lbGiaG.Name = "lbGiaG";
            this.lbGiaG.Size = new System.Drawing.Size(50, 17);
            this.lbGiaG.TabIndex = 58;
            this.lbGiaG.Text = "Giá gốc";
            // 
            // lbNhaCC
            // 
            this.lbNhaCC.AutoSize = true;
            this.lbNhaCC.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNhaCC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbNhaCC.Location = new System.Drawing.Point(446, 42);
            this.lbNhaCC.Name = "lbNhaCC";
            this.lbNhaCC.Size = new System.Drawing.Size(84, 17);
            this.lbNhaCC.TabIndex = 56;
            this.lbNhaCC.Text = "Nhà cung cấp";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel10.Location = new System.Drawing.Point(22, 216);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(383, 1);
            this.panel10.TabIndex = 52;
            // 
            // lbTacG
            // 
            this.lbTacG.AutoSize = true;
            this.lbTacG.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTacG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbTacG.Location = new System.Drawing.Point(29, 169);
            this.lbTacG.Name = "lbTacG";
            this.lbTacG.Size = new System.Drawing.Size(45, 17);
            this.lbTacG.TabIndex = 50;
            this.lbTacG.Text = "Tác giả";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel7.Location = new System.Drawing.Point(434, 404);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(387, 1);
            this.panel7.TabIndex = 49;
            // 
            // lbMoT
            // 
            this.lbMoT.AutoSize = true;
            this.lbMoT.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMoT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbMoT.Location = new System.Drawing.Point(446, 356);
            this.lbMoT.Name = "lbMoT";
            this.lbMoT.Size = new System.Drawing.Size(68, 17);
            this.lbMoT.TabIndex = 47;
            this.lbMoT.Text = "Mô tả sách";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel6.Location = new System.Drawing.Point(22, 342);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(383, 1);
            this.panel6.TabIndex = 46;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.grbThongTin);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 6.75F);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 568);
            this.panel1.TabIndex = 18;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.label4.Location = new System.Drawing.Point(362, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 31);
            this.label4.TabIndex = 31;
            this.label4.Text = "Add/Edit";
            // 
            // grbThongTin
            // 
            this.grbThongTin.BackColor = System.Drawing.Color.White;
            this.grbThongTin.Controls.Add(this.panel9);
            this.grbThongTin.Controls.Add(this.lbSoL);
            this.grbThongTin.Controls.Add(this.txtSL);
            this.grbThongTin.Controls.Add(this.panel15);
            this.grbThongTin.Controls.Add(this.panel16);
            this.grbThongTin.Controls.Add(this.panel17);
            this.grbThongTin.Controls.Add(this.lbNgayN);
            this.grbThongTin.Controls.Add(this.lbGiaG);
            this.grbThongTin.Controls.Add(this.lbNhaCC);
            this.grbThongTin.Controls.Add(this.txtGiaGoc);
            this.grbThongTin.Controls.Add(this.txtNgayNhap);
            this.grbThongTin.Controls.Add(this.txtNCC);
            this.grbThongTin.Controls.Add(this.panel10);
            this.grbThongTin.Controls.Add(this.lbTacG);
            this.grbThongTin.Controls.Add(this.txtTacGia);
            this.grbThongTin.Controls.Add(this.panel7);
            this.grbThongTin.Controls.Add(this.lbMoT);
            this.grbThongTin.Controls.Add(this.txtMoTa);
            this.grbThongTin.Controls.Add(this.panel6);
            this.grbThongTin.Controls.Add(this.lbNhaXB);
            this.grbThongTin.Controls.Add(this.panel5);
            this.grbThongTin.Controls.Add(this.txtNXB);
            this.grbThongTin.Controls.Add(this.panel4);
            this.grbThongTin.Controls.Add(this.btnSua);
            this.grbThongTin.Controls.Add(this.btnThem);
            this.grbThongTin.Controls.Add(this.btnLuuSach);
            this.grbThongTin.Controls.Add(this.panel3);
            this.grbThongTin.Controls.Add(this.panel2);
            this.grbThongTin.Controls.Add(this.panel8);
            this.grbThongTin.Controls.Add(this.lbGiaB);
            this.grbThongTin.Controls.Add(this.lbNamSB);
            this.grbThongTin.Controls.Add(this.lbTheL);
            this.grbThongTin.Controls.Add(this.lbTenS);
            this.grbThongTin.Controls.Add(this.txtNamXB);
            this.grbThongTin.Controls.Add(this.lbMaS);
            this.grbThongTin.Controls.Add(this.txtTenSach);
            this.grbThongTin.Controls.Add(this.txtGiaBan);
            this.grbThongTin.Controls.Add(this.txtTheLoai);
            this.grbThongTin.Controls.Add(this.txtMaSach);
            this.grbThongTin.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbThongTin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.grbThongTin.Location = new System.Drawing.Point(12, 49);
            this.grbThongTin.Name = "grbThongTin";
            this.grbThongTin.Size = new System.Drawing.Size(848, 507);
            this.grbThongTin.TabIndex = 30;
            this.grbThongTin.TabStop = false;
            this.grbThongTin.Text = "Nhập thông tin sách";
            // 
            // txtSL
            // 
            this.txtSL.AcceptsReturn = false;
            this.txtSL.AcceptsTab = false;
            this.txtSL.AnimationSpeed = 200;
            this.txtSL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSL.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSL.BackColor = System.Drawing.Color.Transparent;
            this.txtSL.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSL.BackgroundImage")));
            this.txtSL.BorderColorActive = System.Drawing.Color.Empty;
            this.txtSL.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtSL.BorderColorHover = System.Drawing.Color.Empty;
            this.txtSL.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtSL.BorderRadius = 1;
            this.txtSL.BorderThickness = 1;
            this.txtSL.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSL.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSL.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSL.DefaultText = "";
            this.txtSL.FillColor = System.Drawing.Color.White;
            this.txtSL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtSL.HideSelection = true;
            this.txtSL.IconLeft = null;
            this.txtSL.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSL.IconPadding = 10;
            this.txtSL.IconRight = null;
            this.txtSL.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSL.Lines = new string[0];
            this.txtSL.Location = new System.Drawing.Point(434, 120);
            this.txtSL.MaxLength = 32767;
            this.txtSL.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtSL.Modified = false;
            this.txtSL.Multiline = false;
            this.txtSL.Name = "txtSL";
            stateProperties1.BorderColor = System.Drawing.Color.Empty;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSL.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Transparent;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSL.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.Empty;
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSL.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Transparent;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSL.OnIdleState = stateProperties4;
            this.txtSL.PasswordChar = '\0';
            this.txtSL.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtSL.PlaceholderText = "Số lượng";
            this.txtSL.ReadOnly = false;
            this.txtSL.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSL.SelectedText = "";
            this.txtSL.SelectionLength = 0;
            this.txtSL.SelectionStart = 0;
            this.txtSL.ShortcutsEnabled = true;
            this.txtSL.Size = new System.Drawing.Size(387, 33);
            this.txtSL.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtSL.TabIndex = 77;
            this.txtSL.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSL.TextMarginBottom = 0;
            this.txtSL.TextMarginLeft = 0;
            this.txtSL.TextMarginTop = 0;
            this.txtSL.TextPlaceholder = "Số lượng";
            this.txtSL.UseSystemPasswordChar = false;
            this.txtSL.WordWrap = true;
            this.txtSL.TextChanged += new System.EventHandler(this.txtSL_TextChanged);
            // 
            // txtGiaGoc
            // 
            this.txtGiaGoc.AcceptsReturn = false;
            this.txtGiaGoc.AcceptsTab = false;
            this.txtGiaGoc.AnimationSpeed = 200;
            this.txtGiaGoc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtGiaGoc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtGiaGoc.BackColor = System.Drawing.Color.Transparent;
            this.txtGiaGoc.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtGiaGoc.BackgroundImage")));
            this.txtGiaGoc.BorderColorActive = System.Drawing.Color.Empty;
            this.txtGiaGoc.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtGiaGoc.BorderColorHover = System.Drawing.Color.Empty;
            this.txtGiaGoc.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtGiaGoc.BorderRadius = 1;
            this.txtGiaGoc.BorderThickness = 1;
            this.txtGiaGoc.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtGiaGoc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaGoc.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaGoc.DefaultText = "";
            this.txtGiaGoc.FillColor = System.Drawing.Color.White;
            this.txtGiaGoc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaGoc.HideSelection = true;
            this.txtGiaGoc.IconLeft = null;
            this.txtGiaGoc.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaGoc.IconPadding = 10;
            this.txtGiaGoc.IconRight = null;
            this.txtGiaGoc.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaGoc.Lines = new string[0];
            this.txtGiaGoc.Location = new System.Drawing.Point(434, 248);
            this.txtGiaGoc.MaxLength = 32767;
            this.txtGiaGoc.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtGiaGoc.Modified = false;
            this.txtGiaGoc.Multiline = false;
            this.txtGiaGoc.Name = "txtGiaGoc";
            stateProperties5.BorderColor = System.Drawing.Color.Empty;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaGoc.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Transparent;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtGiaGoc.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.Empty;
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaGoc.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Transparent;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaGoc.OnIdleState = stateProperties8;
            this.txtGiaGoc.PasswordChar = '\0';
            this.txtGiaGoc.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaGoc.PlaceholderText = "Giá gốc";
            this.txtGiaGoc.ReadOnly = false;
            this.txtGiaGoc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGiaGoc.SelectedText = "";
            this.txtGiaGoc.SelectionLength = 0;
            this.txtGiaGoc.SelectionStart = 0;
            this.txtGiaGoc.ShortcutsEnabled = true;
            this.txtGiaGoc.Size = new System.Drawing.Size(387, 33);
            this.txtGiaGoc.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtGiaGoc.TabIndex = 55;
            this.txtGiaGoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGiaGoc.TextMarginBottom = 0;
            this.txtGiaGoc.TextMarginLeft = 0;
            this.txtGiaGoc.TextMarginTop = 0;
            this.txtGiaGoc.TextPlaceholder = "Giá gốc";
            this.txtGiaGoc.UseSystemPasswordChar = false;
            this.txtGiaGoc.WordWrap = true;
            this.txtGiaGoc.TextChanged += new System.EventHandler(this.txtGiaGoc_TextChanged);
            // 
            // txtNgayNhap
            // 
            this.txtNgayNhap.AcceptsReturn = false;
            this.txtNgayNhap.AcceptsTab = false;
            this.txtNgayNhap.AnimationSpeed = 200;
            this.txtNgayNhap.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNgayNhap.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNgayNhap.BackColor = System.Drawing.Color.Transparent;
            this.txtNgayNhap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNgayNhap.BackgroundImage")));
            this.txtNgayNhap.BorderColorActive = System.Drawing.Color.Empty;
            this.txtNgayNhap.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtNgayNhap.BorderColorHover = System.Drawing.Color.Empty;
            this.txtNgayNhap.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtNgayNhap.BorderRadius = 1;
            this.txtNgayNhap.BorderThickness = 1;
            this.txtNgayNhap.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNgayNhap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNgayNhap.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNgayNhap.DefaultText = "";
            this.txtNgayNhap.FillColor = System.Drawing.Color.White;
            this.txtNgayNhap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNgayNhap.HideSelection = true;
            this.txtNgayNhap.IconLeft = null;
            this.txtNgayNhap.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNgayNhap.IconPadding = 10;
            this.txtNgayNhap.IconRight = null;
            this.txtNgayNhap.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNgayNhap.Lines = new string[0];
            this.txtNgayNhap.Location = new System.Drawing.Point(22, 373);
            this.txtNgayNhap.MaxLength = 32767;
            this.txtNgayNhap.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtNgayNhap.Modified = false;
            this.txtNgayNhap.Multiline = false;
            this.txtNgayNhap.Name = "txtNgayNhap";
            stateProperties9.BorderColor = System.Drawing.Color.Empty;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNgayNhap.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Transparent;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNgayNhap.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.Empty;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNgayNhap.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Transparent;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNgayNhap.OnIdleState = stateProperties12;
            this.txtNgayNhap.PasswordChar = '\0';
            this.txtNgayNhap.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNgayNhap.PlaceholderText = "Ngày nhập";
            this.txtNgayNhap.ReadOnly = true;
            this.txtNgayNhap.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNgayNhap.SelectedText = "";
            this.txtNgayNhap.SelectionLength = 0;
            this.txtNgayNhap.SelectionStart = 0;
            this.txtNgayNhap.ShortcutsEnabled = true;
            this.txtNgayNhap.Size = new System.Drawing.Size(383, 33);
            this.txtNgayNhap.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtNgayNhap.TabIndex = 62;
            this.txtNgayNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNgayNhap.TextMarginBottom = 0;
            this.txtNgayNhap.TextMarginLeft = 0;
            this.txtNgayNhap.TextMarginTop = 0;
            this.txtNgayNhap.TextPlaceholder = "Ngày nhập";
            this.txtNgayNhap.UseSystemPasswordChar = false;
            this.txtNgayNhap.WordWrap = true;
            this.txtNgayNhap.TextChanged += new System.EventHandler(this.txtNgayNhap_TextChanged);
            // 
            // txtNCC
            // 
            this.txtNCC.AcceptsReturn = false;
            this.txtNCC.AcceptsTab = false;
            this.txtNCC.AnimationSpeed = 200;
            this.txtNCC.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNCC.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNCC.BackColor = System.Drawing.Color.Transparent;
            this.txtNCC.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNCC.BackgroundImage")));
            this.txtNCC.BorderColorActive = System.Drawing.Color.Empty;
            this.txtNCC.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtNCC.BorderColorHover = System.Drawing.Color.Empty;
            this.txtNCC.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtNCC.BorderRadius = 1;
            this.txtNCC.BorderThickness = 1;
            this.txtNCC.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNCC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNCC.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtNCC.DefaultText = "";
            this.txtNCC.FillColor = System.Drawing.Color.White;
            this.txtNCC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNCC.HideSelection = true;
            this.txtNCC.IconLeft = null;
            this.txtNCC.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNCC.IconPadding = 10;
            this.txtNCC.IconRight = null;
            this.txtNCC.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNCC.Lines = new string[0];
            this.txtNCC.Location = new System.Drawing.Point(434, 59);
            this.txtNCC.MaxLength = 32767;
            this.txtNCC.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtNCC.Modified = false;
            this.txtNCC.Multiline = false;
            this.txtNCC.Name = "txtNCC";
            stateProperties13.BorderColor = System.Drawing.Color.Empty;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNCC.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Transparent;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNCC.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.Empty;
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNCC.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Transparent;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNCC.OnIdleState = stateProperties16;
            this.txtNCC.PasswordChar = '\0';
            this.txtNCC.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNCC.PlaceholderText = "Nhà cung cấp";
            this.txtNCC.ReadOnly = false;
            this.txtNCC.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNCC.SelectedText = "";
            this.txtNCC.SelectionLength = 0;
            this.txtNCC.SelectionStart = 0;
            this.txtNCC.ShortcutsEnabled = true;
            this.txtNCC.Size = new System.Drawing.Size(387, 33);
            this.txtNCC.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtNCC.TabIndex = 53;
            this.txtNCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNCC.TextMarginBottom = 0;
            this.txtNCC.TextMarginLeft = 0;
            this.txtNCC.TextMarginTop = 0;
            this.txtNCC.TextPlaceholder = "Nhà cung cấp";
            this.txtNCC.UseSystemPasswordChar = false;
            this.txtNCC.WordWrap = true;
            this.txtNCC.TextChanged += new System.EventHandler(this.txtNCC_TextChanged);
            // 
            // txtTacGia
            // 
            this.txtTacGia.AcceptsReturn = false;
            this.txtTacGia.AcceptsTab = false;
            this.txtTacGia.AnimationSpeed = 200;
            this.txtTacGia.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTacGia.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTacGia.BackColor = System.Drawing.Color.Transparent;
            this.txtTacGia.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTacGia.BackgroundImage")));
            this.txtTacGia.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTacGia.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTacGia.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTacGia.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTacGia.BorderRadius = 1;
            this.txtTacGia.BorderThickness = 1;
            this.txtTacGia.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTacGia.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTacGia.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTacGia.DefaultText = "";
            this.txtTacGia.FillColor = System.Drawing.Color.White;
            this.txtTacGia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTacGia.HideSelection = true;
            this.txtTacGia.IconLeft = null;
            this.txtTacGia.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTacGia.IconPadding = 10;
            this.txtTacGia.IconRight = null;
            this.txtTacGia.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTacGia.Lines = new string[0];
            this.txtTacGia.Location = new System.Drawing.Point(22, 185);
            this.txtTacGia.MaxLength = 32767;
            this.txtTacGia.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTacGia.Modified = false;
            this.txtTacGia.Multiline = false;
            this.txtTacGia.Name = "txtTacGia";
            stateProperties17.BorderColor = System.Drawing.Color.Empty;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTacGia.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Transparent;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTacGia.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.Empty;
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTacGia.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Transparent;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTacGia.OnIdleState = stateProperties20;
            this.txtTacGia.PasswordChar = '\0';
            this.txtTacGia.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTacGia.PlaceholderText = "Tác giả";
            this.txtTacGia.ReadOnly = false;
            this.txtTacGia.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTacGia.SelectedText = "";
            this.txtTacGia.SelectionLength = 0;
            this.txtTacGia.SelectionStart = 0;
            this.txtTacGia.ShortcutsEnabled = true;
            this.txtTacGia.Size = new System.Drawing.Size(383, 33);
            this.txtTacGia.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTacGia.TabIndex = 51;
            this.txtTacGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTacGia.TextMarginBottom = 0;
            this.txtTacGia.TextMarginLeft = 0;
            this.txtTacGia.TextMarginTop = 0;
            this.txtTacGia.TextPlaceholder = "Tác giả";
            this.txtTacGia.UseSystemPasswordChar = false;
            this.txtTacGia.WordWrap = true;
            this.txtTacGia.TextChanged += new System.EventHandler(this.txtTacGia_TextChanged);
            // 
            // txtMoTa
            // 
            this.txtMoTa.AcceptsReturn = false;
            this.txtMoTa.AcceptsTab = false;
            this.txtMoTa.AnimationSpeed = 200;
            this.txtMoTa.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtMoTa.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtMoTa.BackColor = System.Drawing.Color.Transparent;
            this.txtMoTa.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtMoTa.BackgroundImage")));
            this.txtMoTa.BorderColorActive = System.Drawing.Color.Empty;
            this.txtMoTa.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtMoTa.BorderColorHover = System.Drawing.Color.Empty;
            this.txtMoTa.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtMoTa.BorderRadius = 1;
            this.txtMoTa.BorderThickness = 1;
            this.txtMoTa.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtMoTa.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMoTa.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoTa.DefaultText = "";
            this.txtMoTa.FillColor = System.Drawing.Color.White;
            this.txtMoTa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtMoTa.HideSelection = true;
            this.txtMoTa.IconLeft = null;
            this.txtMoTa.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMoTa.IconPadding = 10;
            this.txtMoTa.IconRight = null;
            this.txtMoTa.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMoTa.Lines = new string[0];
            this.txtMoTa.Location = new System.Drawing.Point(434, 374);
            this.txtMoTa.MaxLength = 32767;
            this.txtMoTa.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtMoTa.Modified = false;
            this.txtMoTa.Multiline = false;
            this.txtMoTa.Name = "txtMoTa";
            stateProperties21.BorderColor = System.Drawing.Color.Empty;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMoTa.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Transparent;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtMoTa.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.Empty;
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMoTa.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Transparent;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMoTa.OnIdleState = stateProperties24;
            this.txtMoTa.PasswordChar = '\0';
            this.txtMoTa.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtMoTa.PlaceholderText = "Mô tả sách";
            this.txtMoTa.ReadOnly = false;
            this.txtMoTa.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMoTa.SelectedText = "";
            this.txtMoTa.SelectionLength = 0;
            this.txtMoTa.SelectionStart = 0;
            this.txtMoTa.ShortcutsEnabled = true;
            this.txtMoTa.Size = new System.Drawing.Size(387, 33);
            this.txtMoTa.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtMoTa.TabIndex = 48;
            this.txtMoTa.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtMoTa.TextMarginBottom = 0;
            this.txtMoTa.TextMarginLeft = 0;
            this.txtMoTa.TextMarginTop = 0;
            this.txtMoTa.TextPlaceholder = "Mô tả sách";
            this.txtMoTa.UseSystemPasswordChar = false;
            this.txtMoTa.WordWrap = true;
            this.txtMoTa.TextChanged += new System.EventHandler(this.txtMoTa_TextChanged);
            // 
            // lbNhaXB
            // 
            this.lbNhaXB.AutoSize = true;
            this.lbNhaXB.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNhaXB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbNhaXB.Location = new System.Drawing.Point(29, 293);
            this.lbNhaXB.Name = "lbNhaXB";
            this.lbNhaXB.Size = new System.Drawing.Size(80, 17);
            this.lbNhaXB.TabIndex = 44;
            this.lbNhaXB.Text = "Nhà xuất bản";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel5.Location = new System.Drawing.Point(434, 339);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(387, 1);
            this.panel5.TabIndex = 42;
            // 
            // txtNXB
            // 
            this.txtNXB.AcceptsReturn = false;
            this.txtNXB.AcceptsTab = false;
            this.txtNXB.AnimationSpeed = 200;
            this.txtNXB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNXB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNXB.BackColor = System.Drawing.Color.Transparent;
            this.txtNXB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNXB.BackgroundImage")));
            this.txtNXB.BorderColorActive = System.Drawing.Color.Empty;
            this.txtNXB.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtNXB.BorderColorHover = System.Drawing.Color.Empty;
            this.txtNXB.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtNXB.BorderRadius = 1;
            this.txtNXB.BorderThickness = 1;
            this.txtNXB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNXB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNXB.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNXB.DefaultText = "";
            this.txtNXB.FillColor = System.Drawing.Color.White;
            this.txtNXB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNXB.HideSelection = true;
            this.txtNXB.IconLeft = null;
            this.txtNXB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNXB.IconPadding = 10;
            this.txtNXB.IconRight = null;
            this.txtNXB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNXB.Lines = new string[0];
            this.txtNXB.Location = new System.Drawing.Point(22, 311);
            this.txtNXB.MaxLength = 32767;
            this.txtNXB.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtNXB.Modified = false;
            this.txtNXB.Multiline = false;
            this.txtNXB.Name = "txtNXB";
            stateProperties25.BorderColor = System.Drawing.Color.Empty;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNXB.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Transparent;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNXB.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.Empty;
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNXB.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Transparent;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNXB.OnIdleState = stateProperties28;
            this.txtNXB.PasswordChar = '\0';
            this.txtNXB.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNXB.PlaceholderText = "Nhà xuất bản";
            this.txtNXB.ReadOnly = false;
            this.txtNXB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNXB.SelectedText = "";
            this.txtNXB.SelectionLength = 0;
            this.txtNXB.SelectionStart = 0;
            this.txtNXB.ShortcutsEnabled = true;
            this.txtNXB.Size = new System.Drawing.Size(383, 33);
            this.txtNXB.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtNXB.TabIndex = 45;
            this.txtNXB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNXB.TextMarginBottom = 0;
            this.txtNXB.TextMarginLeft = 0;
            this.txtNXB.TextMarginTop = 0;
            this.txtNXB.TextPlaceholder = "Nhà xuất bản";
            this.txtNXB.UseSystemPasswordChar = false;
            this.txtNXB.WordWrap = true;
            this.txtNXB.TextChanged += new System.EventHandler(this.txtNXB_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel4.Location = new System.Drawing.Point(437, 213);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(383, 1);
            this.panel4.TabIndex = 41;
            // 
            // btnSua
            // 
            this.btnSua.AllowToggling = false;
            this.btnSua.AnimationSpeed = 200;
            this.btnSua.AutoGenerateColors = false;
            this.btnSua.BackColor = System.Drawing.Color.Transparent;
            this.btnSua.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnSua.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSua.BackgroundImage")));
            this.btnSua.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSua.ButtonText = "Sửa";
            this.btnSua.ButtonTextMarginLeft = 10;
            this.btnSua.ColorContrastOnClick = 45;
            this.btnSua.ColorContrastOnHover = 45;
            this.btnSua.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnSua.CustomizableEdges = borderEdges1;
            this.btnSua.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSua.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnSua.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSua.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnSua.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnSua.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnSua.ForeColor = System.Drawing.Color.White;
            this.btnSua.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnSua.IconMarginLeft = 11;
            this.btnSua.IconPadding = 6;
            this.btnSua.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnSua.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnSua.IdleBorderRadius = 3;
            this.btnSua.IdleBorderThickness = 1;
            this.btnSua.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnSua.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnSua.IdleIconLeftImage")));
            this.btnSua.IdleIconRightImage = null;
            this.btnSua.IndicateFocus = false;
            this.btnSua.Location = new System.Drawing.Point(479, 445);
            this.btnSua.Name = "btnSua";
            stateProperties29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties29.BorderRadius = 3;
            stateProperties29.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties29.BorderThickness = 1;
            stateProperties29.FillColor = System.Drawing.Color.White;
            stateProperties29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties29.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties29.IconLeftImage")));
            stateProperties29.IconRightImage = null;
            this.btnSua.onHoverState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Transparent;
            stateProperties30.BorderRadius = 3;
            stateProperties30.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties30.BorderThickness = 1;
            stateProperties30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties30.ForeColor = System.Drawing.Color.White;
            stateProperties30.IconLeftImage = null;
            stateProperties30.IconRightImage = null;
            this.btnSua.OnPressedState = stateProperties30;
            this.btnSua.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSua.Size = new System.Drawing.Size(99, 33);
            this.btnSua.TabIndex = 38;
            this.btnSua.TabStop = false;
            this.btnSua.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSua.TextMarginLeft = 10;
            this.btnSua.UseDefaultRadiusAndThickness = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThem
            // 
            this.btnThem.AllowToggling = false;
            this.btnThem.AnimationSpeed = 200;
            this.btnThem.AutoGenerateColors = false;
            this.btnThem.BackColor = System.Drawing.Color.Transparent;
            this.btnThem.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnThem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnThem.BackgroundImage")));
            this.btnThem.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnThem.ButtonText = "Thêm";
            this.btnThem.ButtonTextMarginLeft = 10;
            this.btnThem.ColorContrastOnClick = 45;
            this.btnThem.ColorContrastOnHover = 45;
            this.btnThem.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnThem.CustomizableEdges = borderEdges2;
            this.btnThem.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnThem.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnThem.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnThem.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnThem.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnThem.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnThem.ForeColor = System.Drawing.Color.White;
            this.btnThem.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnThem.IconMarginLeft = 11;
            this.btnThem.IconPadding = 6;
            this.btnThem.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnThem.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnThem.IdleBorderRadius = 3;
            this.btnThem.IdleBorderThickness = 1;
            this.btnThem.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnThem.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnThem.IdleIconLeftImage")));
            this.btnThem.IdleIconRightImage = null;
            this.btnThem.IndicateFocus = false;
            this.btnThem.Location = new System.Drawing.Point(602, 445);
            this.btnThem.Name = "btnThem";
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties31.BorderRadius = 3;
            stateProperties31.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties31.BorderThickness = 1;
            stateProperties31.FillColor = System.Drawing.Color.White;
            stateProperties31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties31.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties31.IconLeftImage")));
            stateProperties31.IconRightImage = null;
            this.btnThem.onHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Transparent;
            stateProperties32.BorderRadius = 3;
            stateProperties32.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties32.BorderThickness = 1;
            stateProperties32.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties32.ForeColor = System.Drawing.Color.White;
            stateProperties32.IconLeftImage = null;
            stateProperties32.IconRightImage = null;
            this.btnThem.OnPressedState = stateProperties32;
            this.btnThem.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnThem.Size = new System.Drawing.Size(99, 33);
            this.btnThem.TabIndex = 38;
            this.btnThem.TabStop = false;
            this.btnThem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnThem.TextMarginLeft = 10;
            this.btnThem.UseDefaultRadiusAndThickness = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnLuuSach
            // 
            this.btnLuuSach.AllowToggling = false;
            this.btnLuuSach.AnimationSpeed = 200;
            this.btnLuuSach.AutoGenerateColors = false;
            this.btnLuuSach.BackColor = System.Drawing.Color.Transparent;
            this.btnLuuSach.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnLuuSach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLuuSach.BackgroundImage")));
            this.btnLuuSach.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLuuSach.ButtonText = "Lưu";
            this.btnLuuSach.ButtonTextMarginLeft = 10;
            this.btnLuuSach.ColorContrastOnClick = 45;
            this.btnLuuSach.ColorContrastOnHover = 45;
            this.btnLuuSach.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnLuuSach.CustomizableEdges = borderEdges3;
            this.btnLuuSach.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnLuuSach.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnLuuSach.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnLuuSach.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnLuuSach.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnLuuSach.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuuSach.ForeColor = System.Drawing.Color.White;
            this.btnLuuSach.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLuuSach.IconMarginLeft = 11;
            this.btnLuuSach.IconPadding = 6;
            this.btnLuuSach.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLuuSach.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnLuuSach.IdleBorderRadius = 3;
            this.btnLuuSach.IdleBorderThickness = 1;
            this.btnLuuSach.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnLuuSach.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnLuuSach.IdleIconLeftImage")));
            this.btnLuuSach.IdleIconRightImage = null;
            this.btnLuuSach.IndicateFocus = false;
            this.btnLuuSach.Location = new System.Drawing.Point(725, 445);
            this.btnLuuSach.Name = "btnLuuSach";
            stateProperties33.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties33.BorderRadius = 3;
            stateProperties33.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties33.BorderThickness = 1;
            stateProperties33.FillColor = System.Drawing.Color.White;
            stateProperties33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties33.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties33.IconLeftImage")));
            stateProperties33.IconRightImage = null;
            this.btnLuuSach.onHoverState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.Transparent;
            stateProperties34.BorderRadius = 3;
            stateProperties34.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties34.BorderThickness = 1;
            stateProperties34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties34.ForeColor = System.Drawing.Color.White;
            stateProperties34.IconLeftImage = null;
            stateProperties34.IconRightImage = null;
            this.btnLuuSach.OnPressedState = stateProperties34;
            this.btnLuuSach.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLuuSach.Size = new System.Drawing.Size(99, 33);
            this.btnLuuSach.TabIndex = 38;
            this.btnLuuSach.TabStop = false;
            this.btnLuuSach.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLuuSach.TextMarginLeft = 10;
            this.btnLuuSach.UseDefaultRadiusAndThickness = true;
            this.btnLuuSach.Click += new System.EventHandler(this.btnLuuSach_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel3.Location = new System.Drawing.Point(22, 279);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(383, 1);
            this.panel3.TabIndex = 40;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel2.Location = new System.Drawing.Point(22, 153);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(383, 1);
            this.panel2.TabIndex = 43;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel8.Location = new System.Drawing.Point(22, 90);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(383, 1);
            this.panel8.TabIndex = 39;
            // 
            // lbGiaB
            // 
            this.lbGiaB.AutoSize = true;
            this.lbGiaB.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGiaB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbGiaB.Location = new System.Drawing.Point(446, 293);
            this.lbGiaB.Name = "lbGiaB";
            this.lbGiaB.Size = new System.Drawing.Size(50, 17);
            this.lbGiaB.TabIndex = 35;
            this.lbGiaB.Text = "Giá bán";
            // 
            // lbNamSB
            // 
            this.lbNamSB.AutoSize = true;
            this.lbNamSB.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNamSB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbNamSB.Location = new System.Drawing.Point(443, 165);
            this.lbNamSB.Name = "lbNamSB";
            this.lbNamSB.Size = new System.Drawing.Size(84, 17);
            this.lbNamSB.TabIndex = 34;
            this.lbNamSB.Text = "Năm xuất bản";
            // 
            // lbTheL
            // 
            this.lbTheL.AutoSize = true;
            this.lbTheL.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTheL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbTheL.Location = new System.Drawing.Point(29, 230);
            this.lbTheL.Name = "lbTheL";
            this.lbTheL.Size = new System.Drawing.Size(52, 17);
            this.lbTheL.TabIndex = 33;
            this.lbTheL.Text = "Thể loại";
            // 
            // lbTenS
            // 
            this.lbTenS.AutoSize = true;
            this.lbTenS.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbTenS.Location = new System.Drawing.Point(29, 104);
            this.lbTenS.Name = "lbTenS";
            this.lbTenS.Size = new System.Drawing.Size(55, 17);
            this.lbTenS.TabIndex = 32;
            this.lbTenS.Text = "Tên sách";
            // 
            // txtNamXB
            // 
            this.txtNamXB.AcceptsReturn = false;
            this.txtNamXB.AcceptsTab = false;
            this.txtNamXB.AnimationSpeed = 200;
            this.txtNamXB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtNamXB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtNamXB.BackColor = System.Drawing.Color.Transparent;
            this.txtNamXB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtNamXB.BackgroundImage")));
            this.txtNamXB.BorderColorActive = System.Drawing.Color.Empty;
            this.txtNamXB.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtNamXB.BorderColorHover = System.Drawing.Color.Empty;
            this.txtNamXB.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtNamXB.BorderRadius = 1;
            this.txtNamXB.BorderThickness = 1;
            this.txtNamXB.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtNamXB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNamXB.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNamXB.DefaultText = "";
            this.txtNamXB.FillColor = System.Drawing.Color.White;
            this.txtNamXB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNamXB.HideSelection = true;
            this.txtNamXB.IconLeft = null;
            this.txtNamXB.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNamXB.IconPadding = 10;
            this.txtNamXB.IconRight = null;
            this.txtNamXB.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNamXB.Lines = new string[0];
            this.txtNamXB.Location = new System.Drawing.Point(434, 183);
            this.txtNamXB.MaxLength = 32767;
            this.txtNamXB.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtNamXB.Modified = false;
            this.txtNamXB.Multiline = false;
            this.txtNamXB.Name = "txtNamXB";
            stateProperties35.BorderColor = System.Drawing.Color.Empty;
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNamXB.OnActiveState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.Transparent;
            stateProperties36.FillColor = System.Drawing.Color.White;
            stateProperties36.ForeColor = System.Drawing.Color.Empty;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtNamXB.OnDisabledState = stateProperties36;
            stateProperties37.BorderColor = System.Drawing.Color.Empty;
            stateProperties37.FillColor = System.Drawing.Color.Empty;
            stateProperties37.ForeColor = System.Drawing.Color.Empty;
            stateProperties37.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNamXB.OnHoverState = stateProperties37;
            stateProperties38.BorderColor = System.Drawing.Color.Transparent;
            stateProperties38.FillColor = System.Drawing.Color.White;
            stateProperties38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties38.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtNamXB.OnIdleState = stateProperties38;
            this.txtNamXB.PasswordChar = '\0';
            this.txtNamXB.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtNamXB.PlaceholderText = "Năm xuất bản";
            this.txtNamXB.ReadOnly = false;
            this.txtNamXB.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNamXB.SelectedText = "";
            this.txtNamXB.SelectionLength = 0;
            this.txtNamXB.SelectionStart = 0;
            this.txtNamXB.ShortcutsEnabled = true;
            this.txtNamXB.Size = new System.Drawing.Size(383, 33);
            this.txtNamXB.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtNamXB.TabIndex = 31;
            this.txtNamXB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtNamXB.TextMarginBottom = 0;
            this.txtNamXB.TextMarginLeft = 0;
            this.txtNamXB.TextMarginTop = 0;
            this.txtNamXB.TextPlaceholder = "Năm xuất bản";
            this.txtNamXB.UseSystemPasswordChar = false;
            this.txtNamXB.WordWrap = true;
            this.txtNamXB.TextChanged += new System.EventHandler(this.txtNamXB_TextChanged);
            // 
            // lbMaS
            // 
            this.lbMaS.AutoSize = true;
            this.lbMaS.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lbMaS.Location = new System.Drawing.Point(29, 42);
            this.lbMaS.Name = "lbMaS";
            this.lbMaS.Size = new System.Drawing.Size(53, 17);
            this.lbMaS.TabIndex = 30;
            this.lbMaS.Text = "Mã sách";
            // 
            // txtTenSach
            // 
            this.txtTenSach.AcceptsReturn = false;
            this.txtTenSach.AcceptsTab = false;
            this.txtTenSach.AnimationSpeed = 200;
            this.txtTenSach.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTenSach.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTenSach.BackColor = System.Drawing.Color.Transparent;
            this.txtTenSach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTenSach.BackgroundImage")));
            this.txtTenSach.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTenSach.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTenSach.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTenSach.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTenSach.BorderRadius = 1;
            this.txtTenSach.BorderThickness = 1;
            this.txtTenSach.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTenSach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSach.DefaultText = "";
            this.txtTenSach.FillColor = System.Drawing.Color.White;
            this.txtTenSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenSach.HideSelection = true;
            this.txtTenSach.IconLeft = null;
            this.txtTenSach.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.IconPadding = 10;
            this.txtTenSach.IconRight = null;
            this.txtTenSach.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenSach.Lines = new string[0];
            this.txtTenSach.Location = new System.Drawing.Point(22, 122);
            this.txtTenSach.MaxLength = 32767;
            this.txtTenSach.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTenSach.Modified = false;
            this.txtTenSach.Multiline = false;
            this.txtTenSach.Name = "txtTenSach";
            stateProperties39.BorderColor = System.Drawing.Color.Empty;
            stateProperties39.FillColor = System.Drawing.Color.Empty;
            stateProperties39.ForeColor = System.Drawing.Color.Empty;
            stateProperties39.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnActiveState = stateProperties39;
            stateProperties40.BorderColor = System.Drawing.Color.Transparent;
            stateProperties40.FillColor = System.Drawing.Color.White;
            stateProperties40.ForeColor = System.Drawing.Color.Empty;
            stateProperties40.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTenSach.OnDisabledState = stateProperties40;
            stateProperties41.BorderColor = System.Drawing.Color.Empty;
            stateProperties41.FillColor = System.Drawing.Color.Empty;
            stateProperties41.ForeColor = System.Drawing.Color.Empty;
            stateProperties41.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnHoverState = stateProperties41;
            stateProperties42.BorderColor = System.Drawing.Color.Transparent;
            stateProperties42.FillColor = System.Drawing.Color.White;
            stateProperties42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties42.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTenSach.OnIdleState = stateProperties42;
            this.txtTenSach.PasswordChar = '\0';
            this.txtTenSach.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTenSach.PlaceholderText = "Tên sách";
            this.txtTenSach.ReadOnly = false;
            this.txtTenSach.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTenSach.SelectedText = "";
            this.txtTenSach.SelectionLength = 0;
            this.txtTenSach.SelectionStart = 0;
            this.txtTenSach.ShortcutsEnabled = true;
            this.txtTenSach.Size = new System.Drawing.Size(383, 33);
            this.txtTenSach.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTenSach.TabIndex = 29;
            this.txtTenSach.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTenSach.TextMarginBottom = 0;
            this.txtTenSach.TextMarginLeft = 0;
            this.txtTenSach.TextMarginTop = 0;
            this.txtTenSach.TextPlaceholder = "Tên sách";
            this.txtTenSach.UseSystemPasswordChar = false;
            this.txtTenSach.WordWrap = true;
            this.txtTenSach.TextChanged += new System.EventHandler(this.txtTenSach_TextChanged);
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.AcceptsReturn = false;
            this.txtGiaBan.AcceptsTab = false;
            this.txtGiaBan.AnimationSpeed = 200;
            this.txtGiaBan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtGiaBan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtGiaBan.BackColor = System.Drawing.Color.Transparent;
            this.txtGiaBan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtGiaBan.BackgroundImage")));
            this.txtGiaBan.BorderColorActive = System.Drawing.Color.Empty;
            this.txtGiaBan.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtGiaBan.BorderColorHover = System.Drawing.Color.Empty;
            this.txtGiaBan.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtGiaBan.BorderRadius = 1;
            this.txtGiaBan.BorderThickness = 1;
            this.txtGiaBan.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtGiaBan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaBan.DefaultText = "";
            this.txtGiaBan.FillColor = System.Drawing.Color.White;
            this.txtGiaBan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaBan.HideSelection = true;
            this.txtGiaBan.IconLeft = null;
            this.txtGiaBan.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.IconPadding = 10;
            this.txtGiaBan.IconRight = null;
            this.txtGiaBan.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtGiaBan.Lines = new string[0];
            this.txtGiaBan.Location = new System.Drawing.Point(434, 311);
            this.txtGiaBan.MaxLength = 32767;
            this.txtGiaBan.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtGiaBan.Modified = false;
            this.txtGiaBan.Multiline = false;
            this.txtGiaBan.Name = "txtGiaBan";
            stateProperties43.BorderColor = System.Drawing.Color.Empty;
            stateProperties43.FillColor = System.Drawing.Color.Empty;
            stateProperties43.ForeColor = System.Drawing.Color.Empty;
            stateProperties43.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnActiveState = stateProperties43;
            stateProperties44.BorderColor = System.Drawing.Color.Transparent;
            stateProperties44.FillColor = System.Drawing.Color.White;
            stateProperties44.ForeColor = System.Drawing.Color.Empty;
            stateProperties44.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtGiaBan.OnDisabledState = stateProperties44;
            stateProperties45.BorderColor = System.Drawing.Color.Empty;
            stateProperties45.FillColor = System.Drawing.Color.Empty;
            stateProperties45.ForeColor = System.Drawing.Color.Empty;
            stateProperties45.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnHoverState = stateProperties45;
            stateProperties46.BorderColor = System.Drawing.Color.Transparent;
            stateProperties46.FillColor = System.Drawing.Color.White;
            stateProperties46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties46.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtGiaBan.OnIdleState = stateProperties46;
            this.txtGiaBan.PasswordChar = '\0';
            this.txtGiaBan.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtGiaBan.PlaceholderText = "Giá bán";
            this.txtGiaBan.ReadOnly = true;
            this.txtGiaBan.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGiaBan.SelectedText = "";
            this.txtGiaBan.SelectionLength = 0;
            this.txtGiaBan.SelectionStart = 0;
            this.txtGiaBan.ShortcutsEnabled = true;
            this.txtGiaBan.Size = new System.Drawing.Size(387, 33);
            this.txtGiaBan.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtGiaBan.TabIndex = 28;
            this.txtGiaBan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtGiaBan.TextMarginBottom = 0;
            this.txtGiaBan.TextMarginLeft = 0;
            this.txtGiaBan.TextMarginTop = 0;
            this.txtGiaBan.TextPlaceholder = "Giá bán";
            this.txtGiaBan.UseSystemPasswordChar = false;
            this.txtGiaBan.WordWrap = true;
            this.txtGiaBan.TextChanged += new System.EventHandler(this.txtGiaBan_TextChanged);
            // 
            // txtTheLoai
            // 
            this.txtTheLoai.AcceptsReturn = false;
            this.txtTheLoai.AcceptsTab = false;
            this.txtTheLoai.AnimationSpeed = 200;
            this.txtTheLoai.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTheLoai.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTheLoai.BackColor = System.Drawing.Color.Transparent;
            this.txtTheLoai.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTheLoai.BackgroundImage")));
            this.txtTheLoai.BorderColorActive = System.Drawing.Color.Empty;
            this.txtTheLoai.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtTheLoai.BorderColorHover = System.Drawing.Color.Empty;
            this.txtTheLoai.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtTheLoai.BorderRadius = 1;
            this.txtTheLoai.BorderThickness = 1;
            this.txtTheLoai.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTheLoai.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTheLoai.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTheLoai.DefaultText = "";
            this.txtTheLoai.FillColor = System.Drawing.Color.White;
            this.txtTheLoai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTheLoai.HideSelection = true;
            this.txtTheLoai.IconLeft = null;
            this.txtTheLoai.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTheLoai.IconPadding = 10;
            this.txtTheLoai.IconRight = null;
            this.txtTheLoai.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTheLoai.Lines = new string[0];
            this.txtTheLoai.Location = new System.Drawing.Point(22, 248);
            this.txtTheLoai.MaxLength = 32767;
            this.txtTheLoai.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtTheLoai.Modified = false;
            this.txtTheLoai.Multiline = false;
            this.txtTheLoai.Name = "txtTheLoai";
            stateProperties47.BorderColor = System.Drawing.Color.Empty;
            stateProperties47.FillColor = System.Drawing.Color.Empty;
            stateProperties47.ForeColor = System.Drawing.Color.Empty;
            stateProperties47.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTheLoai.OnActiveState = stateProperties47;
            stateProperties48.BorderColor = System.Drawing.Color.Transparent;
            stateProperties48.FillColor = System.Drawing.Color.White;
            stateProperties48.ForeColor = System.Drawing.Color.Empty;
            stateProperties48.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTheLoai.OnDisabledState = stateProperties48;
            stateProperties49.BorderColor = System.Drawing.Color.Empty;
            stateProperties49.FillColor = System.Drawing.Color.Empty;
            stateProperties49.ForeColor = System.Drawing.Color.Empty;
            stateProperties49.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTheLoai.OnHoverState = stateProperties49;
            stateProperties50.BorderColor = System.Drawing.Color.Transparent;
            stateProperties50.FillColor = System.Drawing.Color.White;
            stateProperties50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties50.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTheLoai.OnIdleState = stateProperties50;
            this.txtTheLoai.PasswordChar = '\0';
            this.txtTheLoai.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtTheLoai.PlaceholderText = "Thể loại";
            this.txtTheLoai.ReadOnly = false;
            this.txtTheLoai.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTheLoai.SelectedText = "";
            this.txtTheLoai.SelectionLength = 0;
            this.txtTheLoai.SelectionStart = 0;
            this.txtTheLoai.ShortcutsEnabled = true;
            this.txtTheLoai.Size = new System.Drawing.Size(383, 33);
            this.txtTheLoai.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTheLoai.TabIndex = 36;
            this.txtTheLoai.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtTheLoai.TextMarginBottom = 0;
            this.txtTheLoai.TextMarginLeft = 0;
            this.txtTheLoai.TextMarginTop = 0;
            this.txtTheLoai.TextPlaceholder = "Thể loại";
            this.txtTheLoai.UseSystemPasswordChar = false;
            this.txtTheLoai.WordWrap = true;
            this.txtTheLoai.TextChanged += new System.EventHandler(this.txtTheLoai_TextChanged);
            // 
            // txtMaSach
            // 
            this.txtMaSach.AcceptsReturn = false;
            this.txtMaSach.AcceptsTab = false;
            this.txtMaSach.AnimationSpeed = 200;
            this.txtMaSach.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtMaSach.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtMaSach.BackColor = System.Drawing.Color.Transparent;
            this.txtMaSach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtMaSach.BackgroundImage")));
            this.txtMaSach.BorderColorActive = System.Drawing.Color.Empty;
            this.txtMaSach.BorderColorDisabled = System.Drawing.Color.Transparent;
            this.txtMaSach.BorderColorHover = System.Drawing.Color.Empty;
            this.txtMaSach.BorderColorIdle = System.Drawing.Color.Transparent;
            this.txtMaSach.BorderRadius = 1;
            this.txtMaSach.BorderThickness = 1;
            this.txtMaSach.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtMaSach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMaSach.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtMaSach.DefaultText = "";
            this.txtMaSach.FillColor = System.Drawing.Color.White;
            this.txtMaSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtMaSach.HideSelection = true;
            this.txtMaSach.IconLeft = null;
            this.txtMaSach.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMaSach.IconPadding = 10;
            this.txtMaSach.IconRight = null;
            this.txtMaSach.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMaSach.Lines = new string[0];
            this.txtMaSach.Location = new System.Drawing.Point(22, 59);
            this.txtMaSach.MaxLength = 32767;
            this.txtMaSach.MinimumSize = new System.Drawing.Size(88, 33);
            this.txtMaSach.Modified = false;
            this.txtMaSach.Multiline = false;
            this.txtMaSach.Name = "txtMaSach";
            stateProperties51.BorderColor = System.Drawing.Color.Empty;
            stateProperties51.FillColor = System.Drawing.Color.Empty;
            stateProperties51.ForeColor = System.Drawing.Color.Empty;
            stateProperties51.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMaSach.OnActiveState = stateProperties51;
            stateProperties52.BorderColor = System.Drawing.Color.Transparent;
            stateProperties52.FillColor = System.Drawing.Color.White;
            stateProperties52.ForeColor = System.Drawing.Color.Empty;
            stateProperties52.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtMaSach.OnDisabledState = stateProperties52;
            stateProperties53.BorderColor = System.Drawing.Color.Empty;
            stateProperties53.FillColor = System.Drawing.Color.Empty;
            stateProperties53.ForeColor = System.Drawing.Color.Empty;
            stateProperties53.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMaSach.OnHoverState = stateProperties53;
            stateProperties54.BorderColor = System.Drawing.Color.Transparent;
            stateProperties54.FillColor = System.Drawing.Color.White;
            stateProperties54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties54.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtMaSach.OnIdleState = stateProperties54;
            this.txtMaSach.PasswordChar = '\0';
            this.txtMaSach.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.txtMaSach.PlaceholderText = "Mã sách";
            this.txtMaSach.ReadOnly = false;
            this.txtMaSach.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMaSach.SelectedText = "";
            this.txtMaSach.SelectionLength = 0;
            this.txtMaSach.SelectionStart = 0;
            this.txtMaSach.ShortcutsEnabled = true;
            this.txtMaSach.Size = new System.Drawing.Size(383, 33);
            this.txtMaSach.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtMaSach.TabIndex = 27;
            this.txtMaSach.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtMaSach.TextMarginBottom = 0;
            this.txtMaSach.TextMarginLeft = 0;
            this.txtMaSach.TextMarginTop = 0;
            this.txtMaSach.TextPlaceholder = "Mã sách";
            this.txtMaSach.UseSystemPasswordChar = false;
            this.txtMaSach.WordWrap = true;
            this.txtMaSach.TextChanged += new System.EventHandler(this.txtMaSach_TextChanged);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(27, 27);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 29;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // FrmAddSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(872, 568);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmAddSach";
            this.Text = "FrmAddSach";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grbThongTin.ResumeLayout(false);
            this.grbThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbSoL;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSL;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label lbNgayN;
        private System.Windows.Forms.Label lbGiaG;
        private System.Windows.Forms.Label lbNhaCC;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtGiaGoc;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtNgayNhap;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtNCC;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lbTacG;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTacGia;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbMoT;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtMoTa;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grbThongTin;
        private System.Windows.Forms.Label lbNhaXB;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtNXB;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnLuuSach;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbGiaB;
        private System.Windows.Forms.Label lbNamSB;
        private System.Windows.Forms.Label lbTheL;
        private System.Windows.Forms.Label lbTenS;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtNamXB;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTenSach;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtGiaBan;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTheLoai;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtMaSach;
        private System.Windows.Forms.Label lbMaS;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSua;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnThem;
    }
}