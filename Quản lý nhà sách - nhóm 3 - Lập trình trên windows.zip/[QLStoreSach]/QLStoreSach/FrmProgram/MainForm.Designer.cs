﻿namespace QLStoreSach.FrmProgram
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnLogout = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnQLKho = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnKhachHang = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnBanSach = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnQuanLySach = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnTrangChu = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panelMain = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(42, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Book Store";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel1.Controls.Add(this.bunifuButton1);
            this.panel1.Controls.Add(this.bunifuButton2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1072, 40);
            this.panel1.TabIndex = 10;
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges10;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.White;
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.IdleBorderRadius = 3;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton1.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.IdleIconLeftImage")));
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(977, 1);
            this.bunifuButton1.Name = "bunifuButton1";
            stateProperties19.BorderColor = System.Drawing.Color.Transparent;
            stateProperties19.BorderRadius = 3;
            stateProperties19.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties19.BorderThickness = 1;
            stateProperties19.FillColor = System.Drawing.Color.White;
            stateProperties19.ForeColor = System.Drawing.Color.White;
            stateProperties19.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties19.IconLeftImage")));
            stateProperties19.IconRightImage = null;
            this.bunifuButton1.onHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Transparent;
            stateProperties20.BorderRadius = 3;
            stateProperties20.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties20.BorderThickness = 1;
            stateProperties20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties20.IconLeftImage = null;
            stateProperties20.IconRightImage = null;
            this.bunifuButton1.OnPressedState = stateProperties20;
            this.bunifuButton1.Size = new System.Drawing.Size(38, 38);
            this.bunifuButton1.TabIndex = 11;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges11;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.IdleBorderRadius = 3;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton2.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.IdleIconLeftImage")));
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(1021, 1);
            this.bunifuButton2.Name = "bunifuButton2";
            stateProperties21.BorderColor = System.Drawing.Color.Transparent;
            stateProperties21.BorderRadius = 3;
            stateProperties21.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties21.BorderThickness = 1;
            stateProperties21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties21.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties21.IconLeftImage")));
            stateProperties21.IconRightImage = null;
            this.bunifuButton2.onHoverState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Transparent;
            stateProperties22.BorderRadius = 3;
            stateProperties22.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties22.BorderThickness = 1;
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties22.IconLeftImage = null;
            stateProperties22.IconRightImage = null;
            this.bunifuButton2.OnPressedState = stateProperties22;
            this.bunifuButton2.Size = new System.Drawing.Size(38, 38);
            this.bunifuButton2.TabIndex = 11;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.panel2.Controls.Add(this.btnLogout);
            this.panel2.Controls.Add(this.btnQLKho);
            this.panel2.Controls.Add(this.btnKhachHang);
            this.panel2.Controls.Add(this.bunifuButton3);
            this.panel2.Controls.Add(this.btnBanSach);
            this.panel2.Controls.Add(this.btnQuanLySach);
            this.panel2.Controls.Add(this.btnTrangChu);
            this.panel2.Controls.Add(this.SidePanel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 568);
            this.panel2.TabIndex = 11;
            // 
            // btnLogout
            // 
            this.btnLogout.AllowToggling = false;
            this.btnLogout.AnimationSpeed = 200;
            this.btnLogout.AutoGenerateColors = false;
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnLogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogout.BackgroundImage")));
            this.btnLogout.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnLogout.ButtonText = "Đăng xuất";
            this.btnLogout.ButtonTextMarginLeft = -12;
            this.btnLogout.ColorContrastOnClick = 45;
            this.btnLogout.ColorContrastOnHover = 45;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.btnLogout.CustomizableEdges = borderEdges12;
            this.btnLogout.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnLogout.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnLogout.DisabledFillColor = System.Drawing.Color.White;
            this.btnLogout.DisabledForecolor = System.Drawing.Color.White;
            this.btnLogout.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLogout.IconMarginLeft = 11;
            this.btnLogout.IconPadding = 6;
            this.btnLogout.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLogout.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnLogout.IdleBorderRadius = 3;
            this.btnLogout.IdleBorderThickness = 1;
            this.btnLogout.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnLogout.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnLogout.IdleIconLeftImage")));
            this.btnLogout.IdleIconRightImage = null;
            this.btnLogout.IndicateFocus = false;
            this.btnLogout.Location = new System.Drawing.Point(6, 533);
            this.btnLogout.Name = "btnLogout";
            stateProperties23.BorderColor = System.Drawing.Color.Transparent;
            stateProperties23.BorderRadius = 3;
            stateProperties23.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties23.BorderThickness = 1;
            stateProperties23.FillColor = System.Drawing.Color.White;
            stateProperties23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties23.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties23.IconLeftImage")));
            stateProperties23.IconRightImage = null;
            this.btnLogout.onHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Transparent;
            stateProperties24.BorderRadius = 3;
            stateProperties24.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties24.BorderThickness = 1;
            stateProperties24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties24.ForeColor = System.Drawing.Color.White;
            stateProperties24.IconLeftImage = null;
            stateProperties24.IconRightImage = null;
            this.btnLogout.OnPressedState = stateProperties24;
            this.btnLogout.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLogout.Size = new System.Drawing.Size(194, 35);
            this.btnLogout.TabIndex = 4;
            this.btnLogout.TabStop = false;
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLogout.TextMarginLeft = -12;
            this.btnLogout.UseDefaultRadiusAndThickness = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnQLKho
            // 
            this.btnQLKho.AllowToggling = false;
            this.btnQLKho.AnimationSpeed = 200;
            this.btnQLKho.AutoGenerateColors = false;
            this.btnQLKho.BackColor = System.Drawing.Color.Transparent;
            this.btnQLKho.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnQLKho.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnQLKho.BackgroundImage")));
            this.btnQLKho.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnQLKho.ButtonText = "Quản lý kho";
            this.btnQLKho.ButtonTextMarginLeft = -6;
            this.btnQLKho.ColorContrastOnClick = 45;
            this.btnQLKho.ColorContrastOnHover = 45;
            this.btnQLKho.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges13.BottomLeft = true;
            borderEdges13.BottomRight = true;
            borderEdges13.TopLeft = true;
            borderEdges13.TopRight = true;
            this.btnQLKho.CustomizableEdges = borderEdges13;
            this.btnQLKho.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnQLKho.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnQLKho.DisabledFillColor = System.Drawing.Color.White;
            this.btnQLKho.DisabledForecolor = System.Drawing.Color.White;
            this.btnQLKho.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnQLKho.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnQLKho.ForeColor = System.Drawing.Color.White;
            this.btnQLKho.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQLKho.IconMarginLeft = 11;
            this.btnQLKho.IconPadding = 6;
            this.btnQLKho.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQLKho.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnQLKho.IdleBorderRadius = 3;
            this.btnQLKho.IdleBorderThickness = 1;
            this.btnQLKho.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnQLKho.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnQLKho.IdleIconLeftImage")));
            this.btnQLKho.IdleIconRightImage = null;
            this.btnQLKho.IndicateFocus = false;
            this.btnQLKho.Location = new System.Drawing.Point(6, 274);
            this.btnQLKho.Name = "btnQLKho";
            stateProperties25.BorderColor = System.Drawing.Color.Transparent;
            stateProperties25.BorderRadius = 3;
            stateProperties25.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties25.BorderThickness = 1;
            stateProperties25.FillColor = System.Drawing.Color.White;
            stateProperties25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties25.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties25.IconLeftImage")));
            stateProperties25.IconRightImage = null;
            this.btnQLKho.onHoverState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Transparent;
            stateProperties26.BorderRadius = 3;
            stateProperties26.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties26.BorderThickness = 1;
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties26.ForeColor = System.Drawing.Color.White;
            stateProperties26.IconLeftImage = null;
            stateProperties26.IconRightImage = null;
            this.btnQLKho.OnPressedState = stateProperties26;
            this.btnQLKho.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnQLKho.Size = new System.Drawing.Size(194, 35);
            this.btnQLKho.TabIndex = 4;
            this.btnQLKho.TabStop = false;
            this.btnQLKho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnQLKho.TextMarginLeft = -6;
            this.btnQLKho.UseDefaultRadiusAndThickness = true;
            this.btnQLKho.Click += new System.EventHandler(this.btnQLKho_Click);
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.AllowToggling = false;
            this.btnKhachHang.AnimationSpeed = 200;
            this.btnKhachHang.AutoGenerateColors = false;
            this.btnKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnKhachHang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.BackgroundImage")));
            this.btnKhachHang.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnKhachHang.ButtonText = "Khách hàng";
            this.btnKhachHang.ButtonTextMarginLeft = -6;
            this.btnKhachHang.ColorContrastOnClick = 45;
            this.btnKhachHang.ColorContrastOnHover = 45;
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges14.BottomLeft = true;
            borderEdges14.BottomRight = true;
            borderEdges14.TopLeft = true;
            borderEdges14.TopRight = true;
            this.btnKhachHang.CustomizableEdges = borderEdges14;
            this.btnKhachHang.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnKhachHang.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnKhachHang.DisabledFillColor = System.Drawing.Color.White;
            this.btnKhachHang.DisabledForecolor = System.Drawing.Color.White;
            this.btnKhachHang.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnKhachHang.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnKhachHang.IconMarginLeft = 11;
            this.btnKhachHang.IconPadding = 6;
            this.btnKhachHang.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnKhachHang.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.IdleBorderRadius = 3;
            this.btnKhachHang.IdleBorderThickness = 1;
            this.btnKhachHang.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnKhachHang.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.IdleIconLeftImage")));
            this.btnKhachHang.IdleIconRightImage = null;
            this.btnKhachHang.IndicateFocus = false;
            this.btnKhachHang.Location = new System.Drawing.Point(6, 186);
            this.btnKhachHang.Name = "btnKhachHang";
            stateProperties27.BorderColor = System.Drawing.Color.Transparent;
            stateProperties27.BorderRadius = 3;
            stateProperties27.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties27.BorderThickness = 1;
            stateProperties27.FillColor = System.Drawing.Color.White;
            stateProperties27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties27.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties27.IconLeftImage")));
            stateProperties27.IconRightImage = null;
            this.btnKhachHang.onHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Transparent;
            stateProperties28.BorderRadius = 3;
            stateProperties28.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties28.BorderThickness = 1;
            stateProperties28.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties28.ForeColor = System.Drawing.Color.White;
            stateProperties28.IconLeftImage = null;
            stateProperties28.IconRightImage = null;
            this.btnKhachHang.OnPressedState = stateProperties28;
            this.btnKhachHang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnKhachHang.Size = new System.Drawing.Size(194, 35);
            this.btnKhachHang.TabIndex = 10;
            this.btnKhachHang.TabStop = false;
            this.btnKhachHang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnKhachHang.TextMarginLeft = -6;
            this.btnKhachHang.UseDefaultRadiusAndThickness = true;
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // bunifuButton3
            // 
            this.bunifuButton3.AllowToggling = false;
            this.bunifuButton3.AnimationSpeed = 200;
            this.bunifuButton3.AutoGenerateColors = false;
            this.bunifuButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.BackgroundImage")));
            this.bunifuButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.ButtonText = "Doanh Thu";
            this.bunifuButton3.ButtonTextMarginLeft = -8;
            this.bunifuButton3.ColorContrastOnClick = 45;
            this.bunifuButton3.ColorContrastOnHover = 45;
            this.bunifuButton3.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges15.BottomLeft = true;
            borderEdges15.BottomRight = true;
            borderEdges15.TopLeft = true;
            borderEdges15.TopRight = true;
            this.bunifuButton3.CustomizableEdges = borderEdges15;
            this.bunifuButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton3.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton3.DisabledFillColor = System.Drawing.Color.White;
            this.bunifuButton3.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.bunifuButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton3.IconMarginLeft = 11;
            this.bunifuButton3.IconPadding = 6;
            this.bunifuButton3.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.bunifuButton3.IdleBorderColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.IdleBorderRadius = 3;
            this.bunifuButton3.IdleBorderThickness = 1;
            this.bunifuButton3.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuButton3.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.IdleIconLeftImage")));
            this.bunifuButton3.IdleIconRightImage = null;
            this.bunifuButton3.IndicateFocus = false;
            this.bunifuButton3.Location = new System.Drawing.Point(6, 230);
            this.bunifuButton3.Name = "bunifuButton3";
            stateProperties29.BorderColor = System.Drawing.Color.Transparent;
            stateProperties29.BorderRadius = 3;
            stateProperties29.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties29.BorderThickness = 1;
            stateProperties29.FillColor = System.Drawing.Color.White;
            stateProperties29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties29.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties29.IconLeftImage")));
            stateProperties29.IconRightImage = null;
            this.bunifuButton3.onHoverState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Transparent;
            stateProperties30.BorderRadius = 3;
            stateProperties30.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties30.BorderThickness = 1;
            stateProperties30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties30.ForeColor = System.Drawing.Color.White;
            stateProperties30.IconLeftImage = null;
            stateProperties30.IconRightImage = null;
            this.bunifuButton3.OnPressedState = stateProperties30;
            this.bunifuButton3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuButton3.Size = new System.Drawing.Size(194, 35);
            this.bunifuButton3.TabIndex = 4;
            this.bunifuButton3.TabStop = false;
            this.bunifuButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton3.TextMarginLeft = -8;
            this.bunifuButton3.UseDefaultRadiusAndThickness = true;
            this.bunifuButton3.Click += new System.EventHandler(this.bunifuButton3_Click);
            // 
            // btnBanSach
            // 
            this.btnBanSach.AllowToggling = false;
            this.btnBanSach.AnimationSpeed = 200;
            this.btnBanSach.AutoGenerateColors = false;
            this.btnBanSach.BackColor = System.Drawing.Color.Transparent;
            this.btnBanSach.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnBanSach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBanSach.BackgroundImage")));
            this.btnBanSach.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBanSach.ButtonText = "Bán sách";
            this.btnBanSach.ButtonTextMarginLeft = -15;
            this.btnBanSach.ColorContrastOnClick = 45;
            this.btnBanSach.ColorContrastOnHover = 45;
            this.btnBanSach.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges16.BottomLeft = true;
            borderEdges16.BottomRight = true;
            borderEdges16.TopLeft = true;
            borderEdges16.TopRight = true;
            this.btnBanSach.CustomizableEdges = borderEdges16;
            this.btnBanSach.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBanSach.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnBanSach.DisabledFillColor = System.Drawing.Color.White;
            this.btnBanSach.DisabledForecolor = System.Drawing.Color.White;
            this.btnBanSach.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnBanSach.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnBanSach.ForeColor = System.Drawing.Color.White;
            this.btnBanSach.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnBanSach.IconMarginLeft = 11;
            this.btnBanSach.IconPadding = 6;
            this.btnBanSach.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnBanSach.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnBanSach.IdleBorderRadius = 3;
            this.btnBanSach.IdleBorderThickness = 1;
            this.btnBanSach.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnBanSach.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnBanSach.IdleIconLeftImage")));
            this.btnBanSach.IdleIconRightImage = null;
            this.btnBanSach.IndicateFocus = false;
            this.btnBanSach.Location = new System.Drawing.Point(6, 142);
            this.btnBanSach.Name = "btnBanSach";
            stateProperties31.BorderColor = System.Drawing.Color.Transparent;
            stateProperties31.BorderRadius = 3;
            stateProperties31.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties31.BorderThickness = 1;
            stateProperties31.FillColor = System.Drawing.Color.White;
            stateProperties31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties31.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties31.IconLeftImage")));
            stateProperties31.IconRightImage = null;
            this.btnBanSach.onHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Transparent;
            stateProperties32.BorderRadius = 3;
            stateProperties32.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties32.BorderThickness = 1;
            stateProperties32.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties32.ForeColor = System.Drawing.Color.White;
            stateProperties32.IconLeftImage = null;
            stateProperties32.IconRightImage = null;
            this.btnBanSach.OnPressedState = stateProperties32;
            this.btnBanSach.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnBanSach.Size = new System.Drawing.Size(194, 35);
            this.btnBanSach.TabIndex = 4;
            this.btnBanSach.TabStop = false;
            this.btnBanSach.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBanSach.TextMarginLeft = -15;
            this.btnBanSach.UseDefaultRadiusAndThickness = true;
            this.btnBanSach.Click += new System.EventHandler(this.btnBanSach_Click);
            // 
            // btnQuanLySach
            // 
            this.btnQuanLySach.AllowToggling = false;
            this.btnQuanLySach.AnimationSpeed = 200;
            this.btnQuanLySach.AutoGenerateColors = false;
            this.btnQuanLySach.BackColor = System.Drawing.Color.Transparent;
            this.btnQuanLySach.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnQuanLySach.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnQuanLySach.BackgroundImage")));
            this.btnQuanLySach.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnQuanLySach.ButtonText = "Quản lý sách";
            this.btnQuanLySach.ButtonTextMarginLeft = -2;
            this.btnQuanLySach.ColorContrastOnClick = 45;
            this.btnQuanLySach.ColorContrastOnHover = 45;
            this.btnQuanLySach.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges17.BottomLeft = true;
            borderEdges17.BottomRight = true;
            borderEdges17.TopLeft = true;
            borderEdges17.TopRight = true;
            this.btnQuanLySach.CustomizableEdges = borderEdges17;
            this.btnQuanLySach.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnQuanLySach.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnQuanLySach.DisabledFillColor = System.Drawing.Color.White;
            this.btnQuanLySach.DisabledForecolor = System.Drawing.Color.White;
            this.btnQuanLySach.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnQuanLySach.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnQuanLySach.ForeColor = System.Drawing.Color.White;
            this.btnQuanLySach.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQuanLySach.IconMarginLeft = 11;
            this.btnQuanLySach.IconPadding = 6;
            this.btnQuanLySach.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnQuanLySach.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnQuanLySach.IdleBorderRadius = 3;
            this.btnQuanLySach.IdleBorderThickness = 1;
            this.btnQuanLySach.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnQuanLySach.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnQuanLySach.IdleIconLeftImage")));
            this.btnQuanLySach.IdleIconRightImage = null;
            this.btnQuanLySach.IndicateFocus = false;
            this.btnQuanLySach.Location = new System.Drawing.Point(6, 98);
            this.btnQuanLySach.Name = "btnQuanLySach";
            stateProperties33.BorderColor = System.Drawing.Color.Transparent;
            stateProperties33.BorderRadius = 3;
            stateProperties33.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties33.BorderThickness = 1;
            stateProperties33.FillColor = System.Drawing.Color.White;
            stateProperties33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties33.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties33.IconLeftImage")));
            stateProperties33.IconRightImage = null;
            this.btnQuanLySach.onHoverState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.Transparent;
            stateProperties34.BorderRadius = 3;
            stateProperties34.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties34.BorderThickness = 1;
            stateProperties34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties34.ForeColor = System.Drawing.Color.White;
            stateProperties34.IconLeftImage = null;
            stateProperties34.IconRightImage = null;
            this.btnQuanLySach.OnPressedState = stateProperties34;
            this.btnQuanLySach.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnQuanLySach.Size = new System.Drawing.Size(194, 35);
            this.btnQuanLySach.TabIndex = 4;
            this.btnQuanLySach.TabStop = false;
            this.btnQuanLySach.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnQuanLySach.TextMarginLeft = -2;
            this.btnQuanLySach.UseDefaultRadiusAndThickness = true;
            this.btnQuanLySach.Click += new System.EventHandler(this.btnQuanLySach_Click);
            // 
            // btnTrangChu
            // 
            this.btnTrangChu.AllowToggling = false;
            this.btnTrangChu.AnimationSpeed = 200;
            this.btnTrangChu.AutoGenerateColors = false;
            this.btnTrangChu.BackColor = System.Drawing.Color.Transparent;
            this.btnTrangChu.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnTrangChu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTrangChu.BackgroundImage")));
            this.btnTrangChu.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnTrangChu.ButtonText = "Trang chủ";
            this.btnTrangChu.ButtonTextMarginLeft = -10;
            this.btnTrangChu.ColorContrastOnClick = 45;
            this.btnTrangChu.ColorContrastOnHover = 45;
            this.btnTrangChu.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges18.BottomLeft = true;
            borderEdges18.BottomRight = true;
            borderEdges18.TopLeft = true;
            borderEdges18.TopRight = true;
            this.btnTrangChu.CustomizableEdges = borderEdges18;
            this.btnTrangChu.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnTrangChu.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnTrangChu.DisabledFillColor = System.Drawing.Color.White;
            this.btnTrangChu.DisabledForecolor = System.Drawing.Color.White;
            this.btnTrangChu.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnTrangChu.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnTrangChu.ForeColor = System.Drawing.Color.White;
            this.btnTrangChu.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnTrangChu.IconMarginLeft = 11;
            this.btnTrangChu.IconPadding = 6;
            this.btnTrangChu.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnTrangChu.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnTrangChu.IdleBorderRadius = 3;
            this.btnTrangChu.IdleBorderThickness = 1;
            this.btnTrangChu.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnTrangChu.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnTrangChu.IdleIconLeftImage")));
            this.btnTrangChu.IdleIconRightImage = null;
            this.btnTrangChu.IndicateFocus = false;
            this.btnTrangChu.Location = new System.Drawing.Point(6, 54);
            this.btnTrangChu.Name = "btnTrangChu";
            stateProperties35.BorderColor = System.Drawing.Color.Transparent;
            stateProperties35.BorderRadius = 3;
            stateProperties35.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties35.BorderThickness = 1;
            stateProperties35.FillColor = System.Drawing.Color.White;
            stateProperties35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties35.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties35.IconLeftImage")));
            stateProperties35.IconRightImage = null;
            this.btnTrangChu.onHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.Transparent;
            stateProperties36.BorderRadius = 3;
            stateProperties36.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties36.BorderThickness = 1;
            stateProperties36.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties36.ForeColor = System.Drawing.Color.White;
            stateProperties36.IconLeftImage = null;
            stateProperties36.IconRightImage = null;
            this.btnTrangChu.OnPressedState = stateProperties36;
            this.btnTrangChu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnTrangChu.Size = new System.Drawing.Size(194, 35);
            this.btnTrangChu.TabIndex = 4;
            this.btnTrangChu.TabStop = false;
            this.btnTrangChu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnTrangChu.TextMarginLeft = -10;
            this.btnTrangChu.UseDefaultRadiusAndThickness = true;
            this.btnTrangChu.Click += new System.EventHandler(this.btnTrangChu_Click);
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.White;
            this.SidePanel.Location = new System.Drawing.Point(3, 54);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(6, 35);
            this.SidePanel.TabIndex = 3;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // panelMain
            // 
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMain.Location = new System.Drawing.Point(200, 40);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(872, 568);
            this.panelMain.TabIndex = 12;
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1072, 608);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnTrangChu;
        private System.Windows.Forms.Panel SidePanel;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnKhachHang;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnBanSach;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnQuanLySach;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnLogout;
        private System.Windows.Forms.Panel panelMain;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnQLKho;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton3;
    }
}