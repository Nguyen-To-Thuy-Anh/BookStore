﻿namespace QLStoreSach.FrmProgram
{
    partial class FrmSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSach));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.label4 = new System.Windows.Forms.Label();
            this.btnKhachHang = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.grbDanhSach = new System.Windows.Forms.GroupBox();
            this.tbTimKiem = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lvDanhSach = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.grbDanhSach.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Elephant", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(2, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Quản lý Sách";
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.AllowToggling = false;
            this.btnKhachHang.AnimationSpeed = 200;
            this.btnKhachHang.AutoGenerateColors = false;
            this.btnKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnKhachHang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.BackgroundImage")));
            this.btnKhachHang.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnKhachHang.ButtonText = "Xem chi tiết";
            this.btnKhachHang.ButtonTextMarginLeft = 15;
            this.btnKhachHang.ColorContrastOnClick = 45;
            this.btnKhachHang.ColorContrastOnHover = 45;
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnKhachHang.CustomizableEdges = borderEdges3;
            this.btnKhachHang.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnKhachHang.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnKhachHang.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnKhachHang.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnKhachHang.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnKhachHang.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnKhachHang.ForeColor = System.Drawing.Color.White;
            this.btnKhachHang.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnKhachHang.IconMarginLeft = 11;
            this.btnKhachHang.IconPadding = 6;
            this.btnKhachHang.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnKhachHang.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.IdleBorderRadius = 3;
            this.btnKhachHang.IdleBorderThickness = 1;
            this.btnKhachHang.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnKhachHang.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.IdleIconLeftImage")));
            this.btnKhachHang.IdleIconRightImage = null;
            this.btnKhachHang.IndicateFocus = false;
            this.btnKhachHang.Location = new System.Drawing.Point(716, 22);
            this.btnKhachHang.Name = "btnKhachHang";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties13.BorderRadius = 3;
            stateProperties13.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties13.BorderThickness = 1;
            stateProperties13.FillColor = System.Drawing.Color.White;
            stateProperties13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties13.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties13.IconLeftImage")));
            stateProperties13.IconRightImage = null;
            this.btnKhachHang.onHoverState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Transparent;
            stateProperties14.BorderRadius = 3;
            stateProperties14.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties14.BorderThickness = 1;
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties14.ForeColor = System.Drawing.Color.White;
            stateProperties14.IconLeftImage = null;
            stateProperties14.IconRightImage = null;
            this.btnKhachHang.OnPressedState = stateProperties14;
            this.btnKhachHang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnKhachHang.Size = new System.Drawing.Size(128, 35);
            this.btnKhachHang.TabIndex = 5;
            this.btnKhachHang.TabStop = false;
            this.btnKhachHang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnKhachHang.TextMarginLeft = 15;
            this.btnKhachHang.UseDefaultRadiusAndThickness = true;
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // grbDanhSach
            // 
            this.grbDanhSach.BackColor = System.Drawing.Color.White;
            this.grbDanhSach.Controls.Add(this.tbTimKiem);
            this.grbDanhSach.Controls.Add(this.btnKhachHang);
            this.grbDanhSach.Controls.Add(this.lvDanhSach);
            this.grbDanhSach.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDanhSach.Location = new System.Drawing.Point(12, 31);
            this.grbDanhSach.Name = "grbDanhSach";
            this.grbDanhSach.Size = new System.Drawing.Size(850, 525);
            this.grbDanhSach.TabIndex = 16;
            this.grbDanhSach.TabStop = false;
            // 
            // tbTimKiem
            // 
            this.tbTimKiem.AcceptsReturn = false;
            this.tbTimKiem.AcceptsTab = false;
            this.tbTimKiem.AnimationSpeed = 200;
            this.tbTimKiem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbTimKiem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbTimKiem.BackColor = System.Drawing.Color.Transparent;
            this.tbTimKiem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.BackgroundImage")));
            this.tbTimKiem.BorderColorActive = System.Drawing.Color.White;
            this.tbTimKiem.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tbTimKiem.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.tbTimKiem.BorderRadius = 35;
            this.tbTimKiem.BorderThickness = 1;
            this.tbTimKiem.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbTimKiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTimKiem.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F);
            this.tbTimKiem.DefaultText = "";
            this.tbTimKiem.FillColor = System.Drawing.Color.White;
            this.tbTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.HideSelection = true;
            this.tbTimKiem.IconLeft = null;
            this.tbTimKiem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.IconPadding = 10;
            this.tbTimKiem.IconRight = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.IconRight")));
            this.tbTimKiem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.Lines = new string[0];
            this.tbTimKiem.Location = new System.Drawing.Point(10, 22);
            this.tbTimKiem.MaxLength = 32767;
            this.tbTimKiem.MinimumSize = new System.Drawing.Size(100, 35);
            this.tbTimKiem.Modified = false;
            this.tbTimKiem.Multiline = false;
            this.tbTimKiem.Name = "tbTimKiem";
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties15.FillColor = System.Drawing.Color.White;
            stateProperties15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnActiveState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbTimKiem.OnDisabledState = stateProperties16;
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties17.FillColor = System.Drawing.Color.White;
            stateProperties17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnHoverState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnIdleState = stateProperties18;
            this.tbTimKiem.PasswordChar = '\0';
            this.tbTimKiem.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.PlaceholderText = "Tìm kiếm sách";
            this.tbTimKiem.ReadOnly = false;
            this.tbTimKiem.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbTimKiem.SelectedText = "";
            this.tbTimKiem.SelectionLength = 0;
            this.tbTimKiem.SelectionStart = 0;
            this.tbTimKiem.ShortcutsEnabled = true;
            this.tbTimKiem.Size = new System.Drawing.Size(312, 35);
            this.tbTimKiem.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tbTimKiem.TabIndex = 7;
            this.tbTimKiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbTimKiem.TextMarginBottom = 0;
            this.tbTimKiem.TextMarginLeft = 5;
            this.tbTimKiem.TextMarginTop = 0;
            this.tbTimKiem.TextPlaceholder = "Tìm kiếm sách";
            this.tbTimKiem.UseSystemPasswordChar = false;
            this.tbTimKiem.WordWrap = true;
            this.tbTimKiem.TextChange += new System.EventHandler(this.tbTimKiem_TextChange);
            // 
            // lvDanhSach
            // 
            this.lvDanhSach.BackColor = System.Drawing.Color.White;
            this.lvDanhSach.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.lvDanhSach.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvDanhSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lvDanhSach.FullRowSelect = true;
            this.lvDanhSach.HideSelection = false;
            this.lvDanhSach.Location = new System.Drawing.Point(10, 70);
            this.lvDanhSach.Name = "lvDanhSach";
            this.lvDanhSach.Size = new System.Drawing.Size(833, 449);
            this.lvDanhSach.TabIndex = 0;
            this.lvDanhSach.UseCompatibleStateImageBehavior = false;
            this.lvDanhSach.View = System.Windows.Forms.View.Details;
            this.lvDanhSach.DoubleClick += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã";
            this.columnHeader1.Width = 66;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên sách";
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tác giả";
            this.columnHeader3.Width = 169;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Thể loại";
            this.columnHeader4.Width = 121;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Năm xuất bản";
            this.columnHeader5.Width = 93;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Nhà xuất bản";
            this.columnHeader6.Width = 92;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Giá bán";
            this.columnHeader7.Width = 115;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.grbDanhSach);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 568);
            this.panel1.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 26);
            this.label1.TabIndex = 17;
            this.label1.Text = "Managing books";
            // 
            // FrmSach
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(872, 568);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Font = new System.Drawing.Font("Century Gothic", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmSach";
            this.Load += new System.EventHandler(this.FrmSach_Load);
            this.grbDanhSach.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnKhachHang;
        private System.Windows.Forms.GroupBox grbDanhSach;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tbTimKiem;
        private System.Windows.Forms.ListView lvDanhSach;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}