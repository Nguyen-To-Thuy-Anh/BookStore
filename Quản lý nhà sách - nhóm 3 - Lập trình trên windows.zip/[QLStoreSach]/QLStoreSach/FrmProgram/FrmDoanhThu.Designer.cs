﻿namespace QLStoreSach.FrmProgram
{
    partial class FrmDoanhThu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDoanhThu));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnXuat = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuDatepicker2 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuDatepicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.tbTimKiem = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lvDoanhThu = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.label4.Location = new System.Drawing.Point(8, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 28);
            this.label4.TabIndex = 14;
            this.label4.Text = "Revenue";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.btnXuat);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.bunifuDatepicker2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.bunifuDatepicker1);
            this.groupBox2.Controls.Add(this.tbTimKiem);
            this.groupBox2.Controls.Add(this.lvDoanhThu);
            this.groupBox2.Location = new System.Drawing.Point(10, 33);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(852, 525);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            // 
            // btnXuat
            // 
            this.btnXuat.AllowToggling = false;
            this.btnXuat.AnimationSpeed = 200;
            this.btnXuat.AutoGenerateColors = false;
            this.btnXuat.BackColor = System.Drawing.Color.Transparent;
            this.btnXuat.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnXuat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnXuat.BackgroundImage")));
            this.btnXuat.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnXuat.ButtonText = "Xuất file";
            this.btnXuat.ButtonTextMarginLeft = 15;
            this.btnXuat.ColorContrastOnClick = 45;
            this.btnXuat.ColorContrastOnHover = 45;
            this.btnXuat.Cursor = System.Windows.Forms.Cursors.Arrow;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnXuat.CustomizableEdges = borderEdges1;
            this.btnXuat.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnXuat.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnXuat.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnXuat.DisabledForecolor = System.Drawing.Color.Gray;
            this.btnXuat.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnXuat.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btnXuat.ForeColor = System.Drawing.Color.White;
            this.btnXuat.IconLeftCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnXuat.IconMarginLeft = 11;
            this.btnXuat.IconPadding = 6;
            this.btnXuat.IconRightCursor = System.Windows.Forms.Cursors.Arrow;
            this.btnXuat.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnXuat.IdleBorderRadius = 3;
            this.btnXuat.IdleBorderThickness = 1;
            this.btnXuat.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.btnXuat.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnXuat.IdleIconLeftImage")));
            this.btnXuat.IdleIconRightImage = null;
            this.btnXuat.IndicateFocus = false;
            this.btnXuat.Location = new System.Drawing.Point(705, 472);
            this.btnXuat.Name = "btnXuat";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties1.BorderRadius = 3;
            stateProperties1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.White;
            stateProperties1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties1.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("stateProperties1.IconLeftImage")));
            stateProperties1.IconRightImage = null;
            this.btnXuat.onHoverState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Transparent;
            stateProperties2.BorderRadius = 3;
            stateProperties2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties2.ForeColor = System.Drawing.Color.White;
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.btnXuat.OnPressedState = stateProperties2;
            this.btnXuat.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnXuat.Size = new System.Drawing.Size(131, 35);
            this.btnXuat.TabIndex = 41;
            this.btnXuat.TabStop = false;
            this.btnXuat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnXuat.TextMarginLeft = 15;
            this.btnXuat.UseDefaultRadiusAndThickness = true;
            this.btnXuat.Click += new System.EventHandler(this.btnXuat_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label2.Location = new System.Drawing.Point(639, 215);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 17);
            this.label2.TabIndex = 40;
            this.label2.Text = "Đến";
            // 
            // bunifuDatepicker2
            // 
            this.bunifuDatepicker2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuDatepicker2.BorderRadius = 10;
            this.bunifuDatepicker2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuDatepicker2.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bunifuDatepicker2.FormatCustom = "yyyy-MM-dd";
            this.bunifuDatepicker2.Location = new System.Drawing.Point(676, 208);
            this.bunifuDatepicker2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.bunifuDatepicker2.Name = "bunifuDatepicker2";
            this.bunifuDatepicker2.Size = new System.Drawing.Size(160, 30);
            this.bunifuDatepicker2.TabIndex = 39;
            this.bunifuDatepicker2.Value = new System.DateTime(2021, 12, 30, 0, 0, 0, 0);
            this.bunifuDatepicker2.onValueChanged += new System.EventHandler(this.bunifuDatepicker2_onValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.label1.Location = new System.Drawing.Point(639, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 17);
            this.label1.TabIndex = 40;
            this.label1.Text = "Từ";
            // 
            // bunifuDatepicker1
            // 
            this.bunifuDatepicker1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.bunifuDatepicker1.BorderRadius = 10;
            this.bunifuDatepicker1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuDatepicker1.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bunifuDatepicker1.FormatCustom = "yyyy-MM-dd";
            this.bunifuDatepicker1.Location = new System.Drawing.Point(676, 68);
            this.bunifuDatepicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bunifuDatepicker1.Name = "bunifuDatepicker1";
            this.bunifuDatepicker1.Size = new System.Drawing.Size(160, 30);
            this.bunifuDatepicker1.TabIndex = 39;
            this.bunifuDatepicker1.Value = new System.DateTime(2021, 12, 30, 8, 7, 0, 0);
            this.bunifuDatepicker1.onValueChanged += new System.EventHandler(this.bunifuDatepicker1_onValueChanged);
            // 
            // tbTimKiem
            // 
            this.tbTimKiem.AcceptsReturn = false;
            this.tbTimKiem.AcceptsTab = false;
            this.tbTimKiem.AnimationSpeed = 200;
            this.tbTimKiem.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbTimKiem.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbTimKiem.BackColor = System.Drawing.Color.Transparent;
            this.tbTimKiem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.BackgroundImage")));
            this.tbTimKiem.BorderColorActive = System.Drawing.Color.White;
            this.tbTimKiem.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tbTimKiem.BorderColorHover = System.Drawing.Color.Black;
            this.tbTimKiem.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            this.tbTimKiem.BorderRadius = 35;
            this.tbTimKiem.BorderThickness = 1;
            this.tbTimKiem.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbTimKiem.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTimKiem.DefaultFont = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTimKiem.DefaultText = "";
            this.tbTimKiem.FillColor = System.Drawing.Color.White;
            this.tbTimKiem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.HideSelection = true;
            this.tbTimKiem.IconLeft = null;
            this.tbTimKiem.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.IconPadding = 10;
            this.tbTimKiem.IconRight = ((System.Drawing.Image)(resources.GetObject("tbTimKiem.IconRight")));
            this.tbTimKiem.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.tbTimKiem.Lines = new string[0];
            this.tbTimKiem.Location = new System.Drawing.Point(15, 20);
            this.tbTimKiem.MaxLength = 32767;
            this.tbTimKiem.MinimumSize = new System.Drawing.Size(100, 35);
            this.tbTimKiem.Modified = false;
            this.tbTimKiem.Multiline = false;
            this.tbTimKiem.Name = "tbTimKiem";
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties3.FillColor = System.Drawing.Color.White;
            stateProperties3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnActiveState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbTimKiem.OnDisabledState = stateProperties4;
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties5.FillColor = System.Drawing.Color.White;
            stateProperties5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnHoverState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(77)))), ((int)(((byte)(153)))));
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTimKiem.OnIdleState = stateProperties6;
            this.tbTimKiem.PasswordChar = '\0';
            this.tbTimKiem.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.tbTimKiem.PlaceholderText = "Tìm kiếm hóa đơn";
            this.tbTimKiem.ReadOnly = false;
            this.tbTimKiem.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbTimKiem.SelectedText = "";
            this.tbTimKiem.SelectionLength = 0;
            this.tbTimKiem.SelectionStart = 0;
            this.tbTimKiem.ShortcutsEnabled = true;
            this.tbTimKiem.Size = new System.Drawing.Size(300, 35);
            this.tbTimKiem.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tbTimKiem.TabIndex = 38;
            this.tbTimKiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbTimKiem.TextMarginBottom = 0;
            this.tbTimKiem.TextMarginLeft = 5;
            this.tbTimKiem.TextMarginTop = 0;
            this.tbTimKiem.TextPlaceholder = "Tìm kiếm hóa đơn";
            this.tbTimKiem.UseSystemPasswordChar = false;
            this.tbTimKiem.WordWrap = true;
            this.tbTimKiem.TextChanged += new System.EventHandler(this.tbTimKiem_TextChanged);
            // 
            // lvDoanhThu
            // 
            this.lvDoanhThu.BackColor = System.Drawing.Color.White;
            this.lvDoanhThu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lvDoanhThu.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader7,
            this.columnHeader1,
            this.columnHeader2});
            this.lvDoanhThu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvDoanhThu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(38)))), ((int)(((byte)(77)))));
            this.lvDoanhThu.FullRowSelect = true;
            this.lvDoanhThu.HideSelection = false;
            this.lvDoanhThu.Location = new System.Drawing.Point(15, 68);
            this.lvDoanhThu.Name = "lvDoanhThu";
            this.lvDoanhThu.Size = new System.Drawing.Size(598, 439);
            this.lvDoanhThu.TabIndex = 37;
            this.lvDoanhThu.UseCompatibleStateImageBehavior = false;
            this.lvDoanhThu.View = System.Windows.Forms.View.Details;
            this.lvDoanhThu.DoubleClick += new System.EventHandler(this.lvDoanhThu_DoubleClick);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Mã hóa đơn";
            this.columnHeader4.Width = 110;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Mã khách hàng";
            this.columnHeader7.Width = 140;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Ngày lập";
            this.columnHeader1.Width = 145;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tổng tiền";
            this.columnHeader2.Width = 180;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 568);
            this.panel1.TabIndex = 21;
            // 
            // FrmDoanhThu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.ClientSize = new System.Drawing.Size(872, 568);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmDoanhThu";
            this.Text = "FrmDoanhThu";
            this.Load += new System.EventHandler(this.FrmDoanhThu_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tbTimKiem;
        private System.Windows.Forms.ListView lvDoanhThu;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnXuat;
    }
}